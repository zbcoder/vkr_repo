from django.apps import AppConfig


class RidHistoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rid_history'
