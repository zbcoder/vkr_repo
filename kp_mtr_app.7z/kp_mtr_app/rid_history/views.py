from ast import Num
from calendar import c
from operator import ne
from re import template
from telnetlib import STATUS
from xmlrpc.client import Boolean
from django.shortcuts import render, redirect
from django.views import generic
from django.core import serializers as ser
from mtr_api.models import *
from .models import Users
import json
import requests
from django.contrib.auth.decorators import permission_required, login_required
from datetime import datetime
from kp_mtr_approve.approve_logic.approve_logic import *
from django.contrib.auth.models import User

# Create your views here.
@login_required
def approves_history_by_rid(request, mtr_rid):
    current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
    current_approves = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)

    rid_obj = Mtr.objects.get(pk=mtr_rid)
    rids = Mtr.objects.filter(mtr_code=rid_obj.mtr_code).order_by('mtr_rid') 
    mtr_resp = requests.get('http://'+ request.get_host()+ f'/api/mtr_info_by_rid/{rid_obj.pk}') 
    approves_by_rid = MtrApproves.objects.filter(mtr_rid=mtr_rid).order_by('approve_round', 'num')
    full_approves_by_code = MtrApproves.objects.filter(Q(mtr_rid=mtr_rid)&Q(num=1)).order_by('mtr_rid')

    print(full_approves_by_code.query)
    return render(request, 'history_rid_info.html', context={
        'current_approves': len(current_approves),
        'approves': approves_by_rid,
        'full_approves_by_code': full_approves_by_code,
        'old_rids': rids,
        'info_by_rid': mtr_resp.json()
    })