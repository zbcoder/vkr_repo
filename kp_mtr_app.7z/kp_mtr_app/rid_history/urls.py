from django.urls import path, include
from .views import *

urlpatterns =[
    path(r'<int:mtr_rid>', approves_history_by_rid, name='approve_history_by_rid')
]