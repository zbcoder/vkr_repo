from django.db import models

# Create your models here.
class Users(models.Model):
    account_name = models.CharField(max_length=50, blank=True, null=True)
    division = models.CharField(max_length=3)
    surname = models.CharField(max_length=50, blank=True, null=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    patronymic = models.CharField(max_length=50, blank=True, null=True)
    nt_account = models.CharField(max_length=50, blank=True, null=True)
    personal_number = models.CharField(max_length=5)
    sf = models.BooleanField()
    user_full_name = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'users'