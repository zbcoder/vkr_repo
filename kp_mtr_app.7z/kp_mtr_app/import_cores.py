import csv
import json
import psycopg2

connection = psycopg2.connect(
    database="matrix", user="z79436",
    host="astra-develop.main.ecp", port="5432",
    options='-c search_path="mtr"')


cursor = connection.cursor()

cursor.execute('SELECT mtr_rid FROM mtr.mtr')

qs = cursor.fetchone()

print(qs[0])