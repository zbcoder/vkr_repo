from django.contrib.auth.models import User


def isUserExists(login):
    try:
        user = User.objects.get(username=login)
        if user is not None:
            return True
    except User.DoesNotExist:
        return False
