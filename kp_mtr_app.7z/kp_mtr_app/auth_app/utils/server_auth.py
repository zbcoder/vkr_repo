# import pyodbc


# def checkUserIsDev(con):
#     cursor = con.cursor()
#     # sql = "SELECT IS_MEMBER('ADMIN')"
#     sql = "SELECT CASE WHEN пл.подразделение = 079 THEN 1 ELSE 0 END as is_admin FROM МД_КСК.dbo.[_Пользователь_логин] пл WHERE логин = SYSTEM_USER AND CHARINDEX('z', SYSTEM_USER) > 0"
#     cursor.execute(sql)
#     row = cursor.fetchall()
#     is_dev = row[0][0]
#     return bool(is_dev)


# def connectMain(login, password):
#     server = "ECP-SQL07.MAIN.ECP"
#     userName = login
#     userPassword = password
#     try:
#         con = pyodbc.connect(driver='{ODBC Driver 17 for SQL Server}',
#                              server='ECP-SQL07.MAIN.ECP', user=userName, password=userPassword, autocommit='true')
#         return con
#     except:
#         return None
#     # /etc/ssl/opnessl.cnf
#     # MinProtocol = TLSv1.0
#     # CipherString = DEFAULT@SECLEVEL=1
