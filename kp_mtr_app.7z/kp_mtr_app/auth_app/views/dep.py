# def post(self, request):
#     no_login = self.request.POST.get('no_login')
#     if no_login == 'true':
#         return redirect('main_file')
#     else:
#         username = self.request.POST.get('login')
#         password = self.request.POST.get('password')
#         if user_info.isUserExists(username) is True:
#             con = server_auth.connectMain(username, password)
#             if con:
#                 if server_auth.checkUserIsDev(con) is True:
#                     con.close()
#                     user = authenticate(
#                         username=username, password=password)
#                     if user is not None:
#                         login(request, user)
#                         return redirect('dashboard')
#                     else:
#                         messages.error(
#                             request, 'Неверный логин или пароль для учетной записи сервиса')
#                 else:
#                     con.close()
#                     messages.error(
#                         request, 'Данной учетной записи запрещен вход в систему')
#                     return redirect('signin')
#             else:
#                 messages.error(
#                     request, 'Нет доступа к основному серверу')
#                 return redirect('signin')
#         else:
#             messages.error(
#                 request, 'Данная учетная запись отсутствует в системе')
#             return redirect('signin')
