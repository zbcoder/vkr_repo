from django.contrib.auth.views import LoginView, LogoutView
from django.views.generic import TemplateView
from django.shortcuts import redirect, render
from auth_app.utils import server_auth
from django.contrib import messages
from auth_app.utils import user_info
from django.urls import reverse_lazy
from django.contrib.auth import authenticate, login, logout


class SignInPageView(LoginView):
    template_name = "auth_app/signin.html"

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('mtr-list')
        return render(request, self.template_name)

    def post(self, request):
        username = self.request.POST.get('login')
        password = self.request.POST.get('password')
        user = authenticate(
            username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('mtr-list')
        else:
            messages.error(
                request, 'Неверный логин или пароль для учетной записи сервиса или запись отсутствует')
            return redirect('signin')


class SignUpPageView(TemplateView):
    pass


class SignOutPageView(LogoutView):
    next_page = reverse_lazy('signin')
