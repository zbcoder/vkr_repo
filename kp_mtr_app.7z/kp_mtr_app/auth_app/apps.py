from django.apps import AppConfig


class AuthenticateConfig(AppConfig):
    name = 'auth_app'
