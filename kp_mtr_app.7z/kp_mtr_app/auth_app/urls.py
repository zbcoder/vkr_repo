from django.urls import path, reverse_lazy
from auth_app.views import auth
from django.views.generic import RedirectView


urlpatterns = [
    path('signin/', auth.SignInPageView.as_view(), name="signin"),
    path('signup/', auth.SignUpPageView.as_view(), name="signup"),
    path('signout/', auth.SignOutPageView.as_view(), name="signout"),
]
