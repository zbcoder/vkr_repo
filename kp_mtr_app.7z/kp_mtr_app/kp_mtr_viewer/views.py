from email import message
from email.policy import default
import json
from re import L
from urllib import request
from django.db import connections
from django.http import Http404
from django.http import HttpResponseBadRequest, HttpResponseNotAllowed
from kp_mtr_approve.approve_logic.approve_logic import search_function
from django.shortcuts import render, redirect, get_object_or_404
from django.template import RequestContext
from django.utils.datetime_safe import datetime
from django.views import generic
from django.db.models import *
from django.contrib.auth.mixins import LoginRequiredMixin
from kp_mtr_approve.models import Users
from django.core import serializers as ser
from .search import *
from mtr_api.models import *
import requests
from .forms import *
from django.contrib import messages
from kp_mtr_approve.approve_logic.approve_logic import search_mtr




def add_fields(request, mtr_code_pattern):
    con = connections['mtr'].cursor()
    con.execute(f'SELECT fn.field_name, sgf.template, fn.field_id, '
                f'sg.supply_group_id, sgf.supply_group_fields_id, sg.name FROM mtr.supply_group_fields sgf '
                f'inner join mtr.supply_groups sg on sgf.supply_group_id=sg.supply_group_id '
                f'inner join mtr.mtr_groups mg on mg.supply_group_id=sg.supply_group_id '
                f'inner join mtr.fields_names fn on sgf.field_id= fn.field_id '
                f'where mg.mtr_code_pattern={mtr_code_pattern} order by sgf.sort_no')
    mtr_fields = con.fetchall()
    all_fields = FieldsNames.objects.all()
    mtr_group = MtrGroups.objects.get(mtr_code_pattern=mtr_code_pattern)
    con.execute(f'SELECT * FROM mtr.fields_for_rid({mtr_code_pattern})')
    values_list = con.fetchall()
    if request.method == 'GET':
        return render(request, 'add_fields.html', context={'values': values_list, 'mtr_group': mtr_group,
                                                           'fields': mtr_fields, 'all_fields': all_fields,
                                                           'supply_group_id': mtr_fields[0][3],
                                                           'supply_group_name': mtr_fields[0][4]})
    elif request.method == 'POST':
        cursor = connections['mtr'].cursor()
        cursor.execute('SELECT MAX(value_id) from mtr.mtr_fields_values')
        current_id = cursor.fetchone()[0]
        sgf_example = SupplyGroupFields(sort_no=request.POST['sort_no'],
                                        field=FieldsNames.objects.get(field_id=int(request.POST['field_id'])),
                                        supply_group=SupplyGroups.objects.get(pk=request.POST['supply_group']),
                                        template=request.POST['template'],
                                        register=request.POST['register'],
                                        core=bool(request.POST['core']),
                                        type=request.POST['type'])
        return redirect(request.path, context={'values': values_list, 'mtr_group': mtr_group, 'all_fields': all_fields})


class FilteredListView(generic.ListView):
    filterset_class = None

    def get_queryset(self):
        queryset = super().get_queryset()
        self.filterset = self.filterset_class(self.request.GET, queryset=queryset)
        return self.filterset.qs.distinct()

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filterset'] = self.filterset
        return context

    def get_ordering(self):
        ordering = self.request.GET.get('orderby')
        return ordering


class MtrListView(LoginRequiredMixin, generic.ListView):
    login_url = 'signin'
    paginate_by = 15
    model = Mtr
    template_name = 'MTR_list.html'
    code_filter = None
    name_filter = None
    additional_attr = None
    supply_id= None
    
    def get_queryset(self):
        user = self.request.user
        self.code_filter = str(self.request.GET.get('code_filter'))
        self.name_filter = str(self.request.GET.get('name_filter'))

        res = search_mtr(self.request)
        self.supply_id = self.request.GET.get('supply_group') if self.request.GET.get('supply_group') else None
        
        self.additional_attr = self.request.GET.getlist('additional_attr')
        return res
        # if res is None:
        #     return self.model.objects.filter(current=True).order_by('mtr_code')
        # else:
        #     return self.model.objects.filter(pk__in = res).order_by('mtr_code')


    def get_context_data(self, **kwargs):
        context = super(MtrListView, self).get_context_data(**kwargs)
        current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=self.request.user)))
        print(current_user_info)
        current_approves = json.loads(ser.serialize('json', MtrApproves.objects.filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)))
        context['user_info'] = current_user_info
        context['current_approves'] = len(current_approves)
        context['additional_attr'] = self.additional_attr
        context['supply_group'] = SupplyGroups.objects.get(pk=self.supply_id) if self.supply_id is not None else None 
        context['supply_group_fields'] = SupplyGroupFields.objects.values('supply_group_fields_id', 'field__field_name').filter(supply_group=self.supply_id) if self.supply_id is not None else None
        context['fields_values'] = self.request.GET.getlist('field_value')
        mtrs = [i.pk for i in context['object_list']]

        temp_arr = MtrFieldsValues.objects.filter(mtr_rid__in = [i.pk for i in context['object_list']])
        return context


def shared_info_by_mtr(request, mtr_code):
    mtr_qs = Mtr.objects.filter(mtr_code=int(mtr_code), current=True)
    current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
    current_approves = json.loads(ser.serialize('json', MtrApproves.objects.filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)))
    if str(mtr_qs[0].mtr_code).zfill(7)==mtr_code:
        mtr_resp = requests.get('http://'+ request.get_host()+ f'/api/mtr_info_by_rid/{mtr_qs[0].pk}')
        if request.method == 'GET':
            return render(request, 'mtrcode_info.html', context={'info_by_rid': mtr_resp.json(), 'current_approves': len(current_approves)})
    else:
        return HttpResponseBadRequest(f'МТР {mtr_code} не найден')



# НИЖЕ ФУНКЦИИ ДЛЯ ОБНОВЛЕНИЯ таблицы mtr_EXT
def update_price(request):
    if request.method == 'POST':
        print(request.POST)
        form = PriceForm(request.POST)
        if form.is_valid():
            if form.cleaned_data.get('price_start_date') is None or form.cleaned_data.get('price') is None:
                messages.error(request, f'Данные не были обновлены, была отправлена неверно заполненная форма.')
                return redirect(request.META["HTTP_REFERER"].split(request.META["HTTP_ORIGIN"])[1])
            start_date = form.cleaned_data.get('price_start_date')
            new_price = form.cleaned_data.get('price')
            mtr_code = form.cleaned_data.get('mtr_code')
            form.save()
            messages.success(request, f'Цена для кода МТР {mtr_code} обновлена. Цена с {start_date} будет составлять: {new_price}')
        else:
            messages.error(request, f'Вы неверно заполнили форму')
        return redirect(request.META["HTTP_REFERER"].split(request.META["HTTP_ORIGIN"])[1])
    else:
        return HttpResponseBadRequest("Запрашиваемая страница не найдена")


def update_str_store(request):
    print(request.META["HTTP_REFERER"].split(request.META["HTTP_ORIGIN"])[1])
    if request.method == 'POST':
        # instance = get_object_or_404(MtrExt, id=mtr_rid)
        form = StrReserve(request.POST)
        if form.is_valid():
            fields = {
                'mtr_rid': Mtr.objects.get(pk=request.POST.get('mtr_rid')),
                'strategic_reserve_justification': form.cleaned_data.get('strategic_reserve_justification')
            }
            obj, created = MtrExt.objects.update_or_create(mtr_rid=request.POST.get('mtr_rid'), defaults=fields)
            messages.success(request, 'Значение стратегического запаса было успешно обновлено.')
        else:
            messages.error(request, 'Ошибка формы')
        return redirect(request.META["HTTP_REFERER"].split(request.META["HTTP_ORIGIN"])[1])

    else:
        return HttpResponseBadRequest('Запрашиваемая страница не найдена')


def update_tr_rate(request):
    if request.method == 'POST':
        form = TransitRateForm(request.POST)
        if form.is_valid():
            fields = {
                'mtr_rid': Mtr.objects.get(pk=request.POST.get('mtr_rid')), 
                'transit_rate': form.cleaned_data.get('transit_rate'),
                'transit_rate_justification': form.cleaned_data.get('transit_rate_justification')
            }
            
            obj, created = MtrExt.objects.update_or_create(mtr_rid=request.POST.get('mtr_rid'), defaults=fields)
            messages.success(request, 'Значение транзитной нормы было успешно обновлено')
        else:
            messages.error(request, 'Ошибка формы')
        return redirect(request.META["HTTP_REFERER"].split(request.META["HTTP_ORIGIN"])[1])
    else:
        return HttpResponseNotAllowed('Данный метод не доступен для текущей страницы')


def update_gid(request):
    if request.method == 'POST':
        form = GidForm(request.POST)
        if form.is_valid():
            fields = {
                'mtr_rid': Mtr.objects.get(pk=request.POST.get('mtr_rid')),
                'gid': form.cleaned_data.get('gid')
            }
            obj, created = MtrExt.objects.update_or_create(mtr_rid=request.POST.get('mtr_rid'), defaults=fields)
            messages.success(request, 'Значение GID обновлено')
        else:
            messages.error(request, 'Ошибка заполнения формы')
        return redirect(request.META["HTTP_REFERER"].split(request.META["HTTP_ORIGIN"])[1])
    else:
        return HttpResponseNotAllowed('Данный метод не доступен для текущей страницы')


# RID хранится на форме в поле hidden id mtr_rid
def update_another_fields(request):
    if request.method == 'POST':
        form = ExtForm(request.POST)
        print(request.POST)
        if form.is_valid():
            fields = {
                'mtr_rid': Mtr.objects.get(pk=request.POST.get('mtr_rid'))
            }
            for item in request.POST:
                if item=='csrfmiddlewaretoken' or item=='mtr_rid': continue
                fields.update({f'{item}': form.cleaned_data.get(item)})
            print(fields)
            obj, created = MtrExt.objects.update_or_create(mtr_rid = request.POST.get('mtr_rid'), defaults=fields)
        else:
            messages.error(request, 'Ошибка заполнения формы')
        return redirect(request.META["HTTP_REFERER"].split(request.META["HTTP_ORIGIN"])[1])
    else:
        return HttpResponseNotAllowed('Данный метод не доступен для текущей страницы')


# ОБЩАЯ ФУНКЦИЯ ДЛЯ ОБНОВЛЕНИЯ ПОЛЕЙ ДЛЯ МТР_EXT не удаляя остальные (TBD ИДЕЯ ДЛЯ РЕФАКТОРИНГА)