from django.forms import ModelForm
from mtr_api.models import *

class PriceForm(ModelForm):
    class Meta:
        model = MtrPrice
        fields = ['mtr_code', 'price', 'price_justification', 'price_start_date']

class StrReserve(ModelForm):
    class Meta:
        model = MtrExt
        fields = ['strategic_reserve_justification']


class TransitRateForm(ModelForm):
    class Meta:
        model = MtrExt
        fields = ['transit_rate', 'transit_rate_justification']


class GidForm(ModelForm):
    class Meta:
        model = MtrExt
        fields = ['gid'] 


class ExtForm(ModelForm):
    class Meta:
        model = MtrExt
        fields = ['fnn_code', 'ekps_code', 'okpd2_code', 'who_responsible']