from django.urls import path
from .views import *

urlpatterns = [
    path(r'', MtrListView.as_view(), name='mtr-list'),
    # path(r'<int:mtr_rid>', information_for_mtrcode, name="mtr-info"),
    path(r'add/fields/<int:mtr_code_pattern>', add_fields),
    path(r'<str:mtr_code>', shared_info_by_mtr, name='shared-mtr-info'),
    path(r'form_actions/update_price', update_price, name='update-price'),
    path(r'form_actions/update_str_store', update_str_store, name='update-str-store'),
    path(r'form_actions/update_tr_rate', update_tr_rate, name='update-tr-rate'),
    path(r'form_actions/update_gid', update_gid, name='update-gid'),
    path(r'form_actions/update_another_fields', update_another_fields)
]