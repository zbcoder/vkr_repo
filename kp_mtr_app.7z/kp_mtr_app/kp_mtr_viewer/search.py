from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from mtr_api.models import Mtr
from .utils import *


def search(request):
    filters = {
        "mtr_code": request.GET.get("mtr_code"),
        "name": request.GET.get("mtr_name")
    }
    html_queries = {
        "mtr_code":  request.GET.get("mtr_code"),
        "name": request.GET.get("name")
    }

    filters = clean_filters(filters)
    html_queries = clean_filters(html_queries)

    mtrs = Mtr.objects.filter(**filters)
    page = request.GET.get('page', 1)
    paginator = Paginator(mtrs, 8)
    try:
        mtrs = paginator.page(page)
    except PageNotAnInteger:
        mtrs = paginator.page(1)
    except EmptyPage:
        mtrs = paginator.page(paginator.num_pages)
    return mtrs