from contextlib import nullcontext
import csv
import datetime
from importlib.metadata import files
import json
import psycopg2
import sys

connection = psycopg2.connect(
    database="matrix", user="z79436",
    host="astra-develop.main.ecp", port="5432",
    options='-c search_path="mtr"')

executer = connection.cursor()

with open(r'C:\Users\z79436\Desktop\mtr\Данные\csv\dbo.МТР.csv', 'r', encoding='utf-8') as m_csv:
    csv_data = csv.reader((x.replace('\0', '') for x in m_csv), delimiter=',')
    print_counter = 0
    next(csv_data)
    i = 0
    mtr_array_json = []
    mtr_start_rid = 114
    mtr_fields_json = []
    for csv_str in csv_data:
        executer.execute('SELECT mg.mtr_group_id from mtr.mtr_groups mg inner '
                         'join mtr.supply_groups sg on '
                         'sg.supply_group_id = mg.supply_group_id '
                         f'where sg.div_no =\'{csv_str[3]}\' and sg.code=\'{csv_str[4]}\' LIMIT 1')
        try:

            mtr_group_id = executer.fetchone()[0]
        except:
            mtr_group_id = None

        if csv_str[1] == 'null' or csv_str[1].lstrip(' ')=='':
            mtr_code = 0
            continue
        else:
            mtr_code = csv_str[1]
        current_json = {
            'mtr_rid': mtr_start_rid,
            'mtr_code': mtr_code,
            'name': csv_str[5],
            'um_code': csv_str[2] if csv_str[2]!=0 else 796,
            'mtr_group_id': mtr_group_id,
            'current': bool(csv_str[22]) if csv_str[22] != 'null' else 0,
        }
        if mtr_group_id is not None:
            executer.execute('SELECT sgf.supply_group_fields_id, sgf.field_id from mtr.supply_group_fields '
                             'sgf inner join '
                             'mtr.mtr_groups mg on sgf.supply_group_id = mg.supply_group_id '
                             f'where mg.mtr_group_id = {mtr_group_id} ')
            sgf = executer.fetchall()
            current_field = 0
            for field in sgf:
                current_fields = {
                    'supply_group_field_id': field[0],
                    'value': csv_str[6 + current_field],
                    'ts-add': csv_str[18],
                    'mtr_rid': mtr_start_rid,
                    'user_add': csv_str[19]
                }
                mtr_fields_json.append(current_fields)
                current_field += 1
        mtr_array_json.append(current_json)

        i += 1
        mtr_start_rid += 1
        print_counter += 1
        print(print_counter)
        if print_counter == 10000:
            files_iter = 0
            with open(f'C:\Users\z79436\Desktop\mtr\Данные\json\mfv{files_iter}.txt', 'w+') as mfv_out:
                json.dump(mtr_fields_json, mfv_out)

            with open(f'C:\Users\z79436\Desktop\mtr\Данные\json\mtr{files_iter}.txt', 'w+') as mtr_out:
                json.dump(mtr_array_json, mtr_out)
            break
            
            print_counter = 0
            files_iter += 1


with open(r'C:\Users\z79436\Desktop\mtr\Данные\json\mfv.txt', 'w') as mfv_out:
    json.dump(mtr_fields_json, mfv_out)

with open(r'C:\Users\z79436\Desktop\mtr\Данные\json\mtr.txt', 'w') as mtr_out:
    json.dump(mtr_array_json, mtr_out)
