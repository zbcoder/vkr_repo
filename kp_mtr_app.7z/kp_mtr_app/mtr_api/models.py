from django.db import models
import uuid
# Create your models here.



class ApproveSorces(models.Model):
    database = 'mtr'
    source_id = models.IntegerField(primary_key=True)
    source_name = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'approve_sorces'

class FieldsNames(models.Model):
    database = 'mtr'
    def as_dict(self):
        return{
            'field_id': self.field_id,
            'field_name': self.field_name
        }
    field_id = models.AutoField(primary_key=True)
    field_name = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fields_names'


class Mtr(models.Model):
    database = 'mtr'
    def as_dict(self):
        return{
            "mtr_code": self.mtr_code,
            "name": self.name,
            "mtr_rid": self.mtr_rid,
        }
    mtr_code = models.IntegerField(blank=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    um_code = models.ForeignKey('UnitMeasure', models.DO_NOTHING, db_column='um_code', blank=True)
    mtr_rid = models.BigAutoField(primary_key=True)
    mtr_group = models.ForeignKey('MtrGroups', models.DO_NOTHING, blank=True, null=True)
    current = models.BooleanField(blank=True, null=True)
    characteristic = models.CharField(max_length=1000, blank=True)
    chatroom_uid = models.UUIDField(blank=True)
    conditional = models.BooleanField(blank=True, null=True)

    def get_extends(self):
        qs = MtrExt.objects.get(pk=self.mtr_rid)
        return qs

    class Meta:
        ordering = ['mtr_rid']
        managed = False
        db_table = 'mtr'

class MtrApproves(models.Model):
    database = 'mtr'
    mtr_approve_id = models.AutoField(primary_key=True)
    mtr_rid = models.ForeignKey(Mtr, models.DO_NOTHING, db_column='mtr_rid')
    role_id = models.IntegerField()
    ts_approve = models.DateTimeField(blank=True, null=True)
    user_approve = models.CharField(max_length=50, blank=True, null=True)
    ts_create = models.DateTimeField(blank=True, null=True)
    source_create = models.ForeignKey(ApproveSorces, models.DO_NOTHING, db_column='source_create', blank=True, null=True)
    user_create = models.CharField(max_length=50, blank=True, null=True)
    result = models.BooleanField(blank=True, null=True)
    div_no = models.IntegerField(blank=True, null=True)
    num = models.IntegerField(blank=True, null=True)
    approve_round = models.IntegerField(blank=True, null=True)
    class Meta:
        managed = False
        db_table = 'mtr_approves'


class MtrFieldsValues(models.Model):
    database = 'mtr'
    value_id = models.BigAutoField(primary_key=True)
    supply_group_field = models.ForeignKey('SupplyGroupFields', models.DO_NOTHING)
    value = models.CharField(max_length=255, blank=True, null=True)
    ts_add = models.DateTimeField(blank=True, null=True)
    mtr_rid = models.ForeignKey(Mtr, models.DO_NOTHING, db_column='mtr_rid')
    user_add = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mtr_fields_values'


class MtrGroups(models.Model):
    database = 'mtr'
    mtr_group_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    mtr_code_pattern = models.IntegerField()
    supply_group = models.ForeignKey('SupplyGroups', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'mtr_groups'


class SupplyGroupFields(models.Model):
    database = 'mtr'
    supply_group_fields_id = models.AutoField(primary_key=True)
    sort_no = models.IntegerField()
    field = models.ForeignKey(FieldsNames, models.DO_NOTHING)
    supply_group = models.ForeignKey('SupplyGroups', models.DO_NOTHING)
    template = models.CharField(max_length=50, blank=True, null=True)
    register = models.CharField(max_length=1, blank=True, null=True)
    core = models.TextField(blank=True, null=True)  # This field type is a guess.
    type = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'supply_group_fields'


class SupplyGroups(models.Model):
    database = 'mtr'
    def as_dict(self):
        return {
            'div_no':self.div_no
        }
    supply_group_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    div_no = models.CharField(max_length=3)
    code = models.CharField(max_length=2)

    class Meta:
        managed = False
        db_table = 'supply_groups'


class UnitMeasure(models.Model):
    database = 'mtr'
    def as_dict(self):
        return{
            'um_code': self.um_code,
            'um_name': self.um_name
        }
    um_code = models.IntegerField(primary_key=True)
    um_name = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'unit_measure'


class MtrPrice(models.Model):
    database = 'mtr'
    mtr_code = models.IntegerField(blank=True, null=True)
    price = models.TextField(blank=True, null=True)  # This field type is a guess.
    price_justification = models.CharField(max_length=2000, blank=True, null=True)
    price_start_date = models.DateTimeField(blank=True, null=True)
    price_id = models.BigAutoField(primary_key=True)

    class Meta:
        managed = False
        db_table = 'mtr_price'


class MtrLog(models.Model):
    database = 'mtr'
    mtr_log_id = models.BigIntegerField(primary_key=True)
    mtr_rid = models.ForeignKey(Mtr, models.DO_NOTHING, db_column='mtr_rid', blank=True, null=True)
    field = models.IntegerField(blank=True, null=True)
    old_value = models.CharField(max_length=200, blank=True, null=True)
    new_value = models.CharField(max_length=200, blank=True, null=True)
    date = models.DateTimeField(blank=True, null=True)
    user = models.CharField(max_length=50, blank=True, null=True)
    justification = models.CharField(max_length=250, blank=True, null=True)
    text = models.CharField(max_length=2000, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mtr_log'


class MtrExt(models.Model):
    database = 'mtr'
    mtr_rid = models.OneToOneField(Mtr, models.DO_NOTHING, db_column='mtr_rid', primary_key=True)
    gid = models.BigIntegerField(blank=True, null=True)
    fnn_code = models.CharField(max_length=50, blank=True, null=True)
    ekps_code = models.CharField(max_length=50, blank=True, null=True)
    okpd2_code = models.CharField(max_length=50, blank=True, null=True)
    special_requirments = models.CharField(max_length=2000, blank=True, null=True)
    transit_rate = models.DecimalField(max_digits=18, decimal_places=7, blank=True, null=True)
    transit_rate_justification = models.CharField(max_length=2000, blank=True, null=True)
    strategic_reserve_justification = models.CharField(max_length=2000, blank=True, null=True)
    mtr_provis = models.BooleanField(blank=True, null=True)
    who_responsible = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mtr_ext'


class UmTranslation(models.Model):
    database = 'mtr'
    um_translation_id = models.AutoField(primary_key=True)
    mtr_code = models.IntegerField(blank=True, null=True)
    um_code = models.ForeignKey('UnitMeasure', models.DO_NOTHING, db_column='um_code', blank=True, null=True)
    um_code_tech = models.IntegerField(blank=True, null=True)
    coefficient = models.DecimalField(max_digits=18, decimal_places=7, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'um_translation'


