import requests

params = {'supply_group_fields_id': 5,
          'sort_no': 1,
          'field': 3,
          'supply_group': 2,
          'template': '123123',
          'register': 'В',
          'core': 1,
          'type': 'Число'
          }

res = requests.put('http://127.0.0.1:8000/api/supply_group_fields/5', params)

print('Status code: ', res.status_code,
      '\n\n\nHeaders\n____________\n',
      res.headers,
      '\n\n\n\nContent\n__________\n',
      res.content)
