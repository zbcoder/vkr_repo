from django.urls import path, include
from rest_framework import routers

from .views import *

MtrRouter = routers.SimpleRouter()
MtrRouter.register('mtr', MtrViewSet, basename='mtr')
urlpatterns = [
    path(r'', include(MtrRouter.urls)),
    path(r'approves/', MtrApprovesViewSet.as_view({'get': 'list', 'post': 'create'})),
    path(r'mtr_fields_values/', MtrFieldsView.as_view({'get': 'list', 'post': 'create'})), 
    path(r'supply_group_fields/<int:supply_group_fields_id>', SupplyGroupFieldsView.as_view(), name='supply_group_fields'),
    path(r'characteristic_fields/<int:mtr_code_pattern>', MtrFieldsByPattern.as_view(), name='characteristic_fields'),
    path(r'mtr_values_info/<int:mtr_rid>', MtrDetails.as_view()),
    path(r'approves/<int:pk>', MtrApprovesViewSet.as_view({'get': 'retrieve', 'put': 'update'})),
    path(r'mtr_info_by_rid/<int:mtr_rid>', MtrFullInfoByMtrRid.as_view(), name='full_info_by_rid'),
    path(r'available-divisions/', AllDivisions.as_view(), name='get-divisions'),
    path(r'name_by_mtrcode/<int:mtr_code>', NameByCode.as_view(), name='name_by_mtrcode'),
    path(r'mtr_price/<int:mtr_code>', GetMTRPrices.as_view(), name='code_prices'), # ПОКА ЧТО ТОЛЬКО GET ВОЗМОЖНО НУЖНО БУДЕТ ДОБАВИТЬ POST
    path(r'update_characteristic/<int:value_id>', UpdateCharacteristicValue.as_view(), name='update_characteristics'),
    path(r'supply_groups', SupplyGroupsList.as_view(), name='supply_groups_list')
]