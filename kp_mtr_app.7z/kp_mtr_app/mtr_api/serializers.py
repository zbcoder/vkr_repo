from pyexpat import model
from re import L
from rest_framework import serializers
from .models import *


class MtrFieldsValuesSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrFieldsValues
        fields = ['value_id', 'value', 'supply_group_field']
        depth = 2


class SupplyGroupFieldsSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupplyGroupFields
        fields = '__all__'


class MtrSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mtr
        fields = '__all__'


class MtrApprovesSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrApproves
        fields = '__all__'
class FieldsForPatternSerializer(serializers.Serializer):
    field_name = serializers.CharField()
    mtr_group_id = serializers.IntegerField()
    field_id = serializers.IntegerField()
    supply_group_id = serializers.IntegerField()
    name = serializers.CharField()


class DefaultMtrFieldsSerializer():
    value = serializers.CharField()
    field_name = serializers.CharField()


class MtrInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mtr
        fields = '__all__'
        depth = 2


class DivisionOnlySupplyGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupplyGroups
        fields = ['div_no']

class MtrFieldValueUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrFieldsValues
        fields = ['supply_group_field','value']



class MtrPriceSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrPrice
        fields = '__all__'


# СЕРИАЛАЙЗЕР ДЛЯ MTRPRICE
class MtrPriceCustomSerializer(serializers.ModelSerializer):
    # ПЕРЕОПРЕДЕЛЕННАЯ ДАТА В НЕОБХОДИМОМ ФОРМАТЕ
    price_start_date = serializers.DateTimeField(format='%d.%m.%Y')
    class Meta:
        model = MtrPrice
        fields = '__all__'


class MtrExtendsSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = MtrExt
        fields = '__all__'


class MtrGroupsSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrGroups
        fields = '__all__'


class MtrFieldsValuesCustomSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrFieldsValues
        fields = ['mtr_rid__mtr_code'] 


# СЕРИАЛАЙЗЕР ДЛЯ ГРУПП СНАБЖЕНИЯ
class SupplyGroupsSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupplyGroups
        fields = '__all__'