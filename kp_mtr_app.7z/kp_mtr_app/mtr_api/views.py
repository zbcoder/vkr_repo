from http.client import HTTPResponse
from django.shortcuts import render
from rest_framework import status as st
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import api_view
from rest_framework.generics import ListAPIView
from .models import *
from .serializers import *
from django.db import connections
from django.contrib.auth.decorators import login_required


# Create your views here.

class MtrFieldsView(ModelViewSet):
    serializer_class = MtrFieldsValuesSerializer
    queryset = MtrFieldsValues.objects.all()

class SupplyGroupFieldsView(APIView):
    def get(self, request, supply_group_fields_id):
        queryset = SupplyGroupFields.objects.get(pk=supply_group_fields_id)
        serializer = SupplyGroupFieldsSerializer(queryset)
        return Response(serializer.data)

    def put(self, request, supply_group_fields_id):
        print('im in put')
        queryset = SupplyGroupFields.objects.get(pk=supply_group_fields_id)
        serializer = SupplyGroupFieldsSerializer(queryset, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=st.HTTP_400_BAD_REQUEST)


class MtrViewSet(ModelViewSet):
    serializer_class = MtrSerializer
    queryset = Mtr.objects.all()
    

class MtrApprovesViewSet(ModelViewSet):
    serializer_class = MtrApprovesSerializer
    queryset = MtrApproves.objects.all()

    def update(self, request, *args, **kwargs):
        print(request.data)
        if request.data['result'] == 'True':
            mtr_code = Mtr.objects.values('mtr_code').get(pk=request.data['mtr_rid'])
            print(mtr_code['mtr_code'])
            Mtr.objects.filter(mtr_code=mtr_code['mtr_code']).exclude(mtr_rid=request.data['mtr_rid']).update(
                current=False
            )
            _new, _new_mtr = Mtr.objects.update_or_create(mtr_rid=request.data['mtr_rid'],
                                                          defaults={'current': request.data['result']})
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=st.HTTP_201_CREATED, headers=headers)

class MtrFieldsByPattern(APIView):
    def get(self, request, mtr_code_pattern):
        cursor = connections['mtr'].cursor()
        cursor.execute(f'SELECT fn.field_name, mg.mtr_group_id, fn.field_id, '
                       f'sg.supply_group_id, sg.name, sgf.supply_group_fields_id, sgf.template, mg.name, sg.code, sg.div_no, '
                       f'mg.mtr_code_pattern, sgf.sort_no FROM mtr.supply_group_fields sgf '
                       f'inner join mtr.supply_groups sg on sgf.supply_group_id=sg.supply_group_id '
                       f'inner join mtr.mtr_groups mg on mg.supply_group_id=sg.supply_group_id '
                       f'inner join mtr.fields_names fn on sgf.field_id= fn.field_id '
                       f'where mg.mtr_code_pattern={mtr_code_pattern} order by sgf.sort_no ASC')
        serializer = []
        for element in cursor.fetchall():
            tmp_json = {
                "field_name": element[0],
                "mtr_group_id": element[1],
                "field_id": element[2],
                "supply_group_id": element[3],
                "supply_group_name": element[4],
                "supply_group_field_id": element[5],
                "template":  element[6] if element[6] else "",
                "mtr_group_name": element[7],
                "code": element[8],
                "div_no": element[9],
                "group_pattern": str(element[10]).zfill(3),
                "sort_no": element[11]
            }
            serializer.append(tmp_json)
        cursor.execute(f'SELECT * from mtr.get_free_mtrcode({mtr_code_pattern})')
        ff_mtrcode = cursor.fetchone()
        return Response(data={'json': serializer, 'ff_mtrcode': ff_mtrcode[0]})


class MtrDetails(APIView):
    def get(self, request, mtr_rid):
        mtr_fields_qs = MtrFieldsValues.objects.select_related('supply_group_field__field'). \
            select_related('supply_group_field__supply_group'). \
            select_related('mtr_rid').select_related('mtr_rid__mtr_group'). \
            filter(mtr_rid=mtr_rid)
        mf_serializer = MtrFieldsValuesSerializer(mtr_fields_qs, many=True)
        return Response(mf_serializer.data)


#Mtr fields values data by mtr_rid
class MtrFullInfoByMtrRid(APIView):
    def get(self, request, mtr_rid):
        try:
            mtr_obj = Mtr.objects.get(pk=mtr_rid)
            mtr_ext_qs = get_or_none(MtrExt, pk=mtr_obj.pk)
            print('mtr_ext: ',mtr_ext_qs,'\n\n\n\n')
            mtr_fields_qs = MtrFieldsValues.objects.select_related('supply_group_field__field'). \
                select_related('supply_group_field__supply_group'). \
                select_related('mtr_rid').select_related('mtr_rid__mtr_group').select_related('mtr_rid__um_code') \
                .filter(mtr_rid=mtr_rid).order_by('supply_group_field__sort_no')
            mtr_fields_serializer = MtrFieldsValuesSerializer(mtr_fields_qs, many = True)
            mtr_fields_data = mtr_fields_serializer.data
            mtr_qs = Mtr.objects.select_related('mtr_group').select_related('um_code').get(pk=mtr_rid)
            mtr_serializer = MtrInfoSerializer(mtr_qs)
            prices_qs = filter_or_none(MtrPrice, mtr_code=mtr_obj.mtr_code)
            if prices_qs == {}:
                mtr_prices = {}
            else:
                prices_qs = prices_qs.order_by('-price_start_date', '-price_id')
                mtr_prices_ser = MtrPriceSerializer(prices_qs, many=True)
                mtr_prices = mtr_prices_ser.data
           
            if mtr_ext_qs is None:
                mtr_extends = {}
            else:
                try:
                    mtr_extends_ser = MtrExtendsSerializer(mtr_ext_qs)
                    mtr_extends = mtr_extends_ser.data
                except:
                    mtr_extends = {}
            mtr_serializer_data = mtr_serializer.data
        except Exception as err:
            mtr_extends = {}
            mtr_prices = {}
            mtr_fields_data = {}
            mtr_serializer_data = {}
            print(err)
        finally:
            return Response({'mtr_characteristics': mtr_fields_data, 'mtr_info': mtr_serializer_data, 'mtr_ext': mtr_extends, 'mtr_price': mtr_prices})


class AllDivisions(APIView):
    def get(self, request):
        divisons_qs = SupplyGroups.objects.values('div_no').distinct()
        serializer = DivisionOnlySupplyGroupSerializer(divisons_qs, many=True)
        return Response({'divisions': serializer.data})

# Возвращает информацию о текущей ревизии кода МТР
# информацию о группе МТР
# Информацию о характеристиках, поле ГС и значение
# Так же возвращает список цен
class NameByCode(APIView):
    def get(self, request, mtr_code):
        print(mtr_code)
        qs = Mtr.objects.filter(mtr_code=mtr_code, current=True)
        ser = MtrSerializer(qs, many=True)
        group_qs = MtrGroups.objects.get(pk = qs[0].mtr_group.pk)
        group_ser = MtrGroupsSerializer(group_qs)
        mtf_qs = MtrFieldsValues.objects.select_related('supply_group_field').filter(mtr_rid__mtr_code=mtr_code, mtr_rid__current=True).order_by('supply_group_field__sort_no')
        mtf_ser = MtrFieldValueUpdateSerializer(mtf_qs, many=True) 
        mtr_prices_qs = MtrPrice.objects.filter(mtr_code=mtr_code).order_by('price_start_date')
        mtr_prices_ser = MtrPriceSerializer(mtr_prices_qs, many=True)

        print(ser)
        return Response({'data': ser.data, 'group_info': group_ser.data, 'mtf_qs':mtf_ser.data})

class UpdateCharacteristicValue(APIView):
    def put(self, request, value_id):
        queryset = MtrFieldsValues.objects.get(pk=value_id)
        if queryset.mtr_rid.current is not None:
            return Response(status=st.HTTP_400_BAD_REQUEST)
        else:
            serializer = MtrFieldValueUpdateSerializer(queryset, data=request.data)
            if serializer.is_valid():
                serializer.save()
                cursor = connections['mtr'].cursor()
                cursor.execute(f'SELECT * FROM mtr.get_mtr_full_characteristic({queryset.mtr_rid.pk})')
                Mtr.objects.filter(mtr_rid=queryset.mtr_rid.pk).update(characteristic=cursor.fetchone()[0])
                return Response(serializer.data)
            return Response(serializer.errors, status=st.HTTP_404_NOT_FOUND)

# ЦЕНЫ МТР ПО КОДУ
class GetMTRPrices(APIView):
    def get(self, request, mtr_code):
        mtr_prices_qs = MtrPrice.objects.filter(mtr_code=mtr_code).order_by('price_start_date')
        mtr_prices_ser = MtrPriceCustomSerializer(mtr_prices_qs, many=True)
        return Response({'mtr_prices_history': mtr_prices_ser.data})


# все группы снабжения
class SupplyGroupsList(ListAPIView):
    queryset = SupplyGroups.objects.all()
    serializer_class = SupplyGroupsSerializer



# Api's functions 
def get_or_none(model, **kwargs):
    try:
        return model.objects.get(**kwargs)
    except:
        return {}

def filter_or_none(model, **kwargs):
    try:
        return model.objects.filter(**kwargs)
    except:
        return {}