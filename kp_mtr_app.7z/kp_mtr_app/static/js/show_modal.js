function show_modal(){
    modal = new bootstrap.Modal(document.querySelector('#modal_perepis'));
    modal.show();
};
