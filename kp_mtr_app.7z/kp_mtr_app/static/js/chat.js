//chat_id - (uuid, guid)
//chat_api urls - chat_api/chat/ POST new chat
//                chat_api/chat/<uuid> all messages from chat
//                chat_api/chat/add_message/ POST message in chat

placeholder_url = 'http://127.0.0.1:8080/chat_api/'

async function load_chat(chat_id){
    document.querySelector('.message-error-container').classList.add('hidden')
    document.getElementById('chat_loader').classList.remove('hidden');
    const data = await fetch(placeholder_url+'chat/'+chat_id+'/')
    .then((response)=>{
        return response.json();
    })
    .then((data)=>{
        console.log(data[1][0]['chatroom_id'])
        fill_chat(data)
        document.getElementById('chat_loader').classList.add('hidden');
        document.querySelector('#current_room').value=data[1][0]['chatroom_id']
    })
    .catch((err)=>{
        try{

        }
        catch(err)
        
        document.getElementById('chat_loader').classList.add('hidden');
        document.querySelector('.message-error-container').classList.remove('hidden')
        console.log(err)
    })
    .finally(()=>{
        document.querySelector('.messager-container').scrollTop = document.querySelector('.messager-container').scrollHeight;
    })

    console.log(data)
}

function fill_chat(data){
    console.log(data[0].length)
    try{
        for(i=0; i<data[0].length; i++){
            create_message(data[0][i])
        }    
    }
    catch{
        console.log('Это пустой чат')
    }
}

async function post_message(){
    let json_obj = {
        'message_text': document.querySelector('#message_text').value,
        'username': document.querySelector('#current_user').value,
        'post_date': new Date().toISOString(),
        'chatroom': document.querySelector('#current_room').value
    }
    console.log(json_obj, JSON.stringify(json_obj))
    const requestOptions = {
        method: 'POST',
        headers:{'Content-type':'application/json'},
        body: JSON.stringify(json_obj)
    }
    const response = await fetch(placeholder_url+'add-message/', requestOptions)
    .then((response)=>{
        return response.json()
    })
    .then((data)=>{
        document.querySelector('#msg-post-btn').classList.add('disabled');
        create_message(json_obj)
        document.querySelector('#message_text').value = ''
        document.querySelector('#msg-post-btn').classList.add('hidden')
    })
    .catch((err)=>{
        alert('Сообщение не было добавлено');
    })
    .finally(()=>{
        document.querySelector('.messager-container').scrollTop = document.querySelector('.messager-container').scrollHeight;
        document.querySelector('#msg-post-btn').classList.remove('disabled')
    })
}
function create_message(data){
    message_body = document.createElement('div')
        message_body.classList.add('message')
        time_span = document.createElement('span')
        time_span.innerHTML = '<small class="text-form">'+data['post_date'].split('T')[0] +' '+ data['post_date'].split('T')[1].slice(0, -1)+'</small>'

        message_head = document.createElement('h6')
        message_head.innerHTML = 'Отправил: '+data['username']

        message_text = document.createElement('p')
        message_text.innerHTML = data['message_text']
        if(data['username'] == document.querySelector('#current_user').value){
            message_body.classList.add('darker')
            message_body.classList.add('outcoming')
            time_span.classList.add('time-right')
        }
        else{
            message_body.classList.add('incoming')
            time_span.classList.add('time-left')
        }

        message_body.appendChild(message_head)
        message_body.appendChild(message_text)
        message_body.appendChild(time_span)

        document.querySelector('.messager-container').appendChild(message_body);
}

