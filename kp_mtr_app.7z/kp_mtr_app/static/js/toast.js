// Чтобы добавить дополнительное содержимое в футер toast необходимо 
// передавать третьим параметром HTML код, который будет вставлен в футер
// пример: <div><button class="btn btn-dark btn-sm" style="font-size: x-small;">Перезагрузить чат</button></div>
class MaterialToast{
    constructor(toast_message, style, additional=""){
        this.toast_message = toast_message;
        this.toast_content_type = style;
        this.toast_enum_types = {
            "bg-danger": "Ошибка",
            "bg-info": "Информация",
            "bg-success": "Успешное выполнение",
            "bg-warning": "Предупреждение"
        }
        this.additional = additional
    }

    get_toast_uid(){
        var d = new Date().getTime();
        if(window.perfomance && typeof window.performance.now === "function"){
            d += performance.now();
        }
        var uid="toast_xxxx-xxxxxxxxx-xxxx".replace(/[x]/g, function(c){
            var r = (d+Math.random()*16) %16|0;
            d = Math.floor(d/16);
            return (c==="x"?r:(r&0x3|0x8.toString(16)));
        })
        this.toast_uid = uid;
        return uid;
    }

    render(){
        let html_toast = `
        <div class="material-toast d-block" id="${this.get_toast_uid()}">
            <div class="material-toast__head">
                <p style="font-size: small; font-weight: bold;">Сообщение от информационной системы</p>
                <button class="material-btn btn-dark text-light px-1 py-1" onclick="close_toast(this.parentNode)">&times;</button>
                <small class="form-text position-absolute text-muted" style="font-size:x-small; right: 20px; top: 25px;">Только что</small>
            </div>
            <div class="material-toast__body">
                <span class="badge ${this.toast_content_type} text-light rounded-pill w-50 mb-1">${this.toast_enum_types[this.toast_content_type]}</span>
                <p>${this.toast_message}</p>
            </div>
            <div class="material-toast__footer">
                ${this.additional}
            </div>
        </div>
        `
        console.log(html_toast);
        this.set_live_parameters();
        document.querySelector(".toasts-container").appendChild(new Range().createContextualFragment(html_toast))
    }


    set_live_parameters(){
        // Отчет с начала отправки изначально для каждого тоста 0
        var seconds = 0;

        document.querySelector(".toasts-container").style.display = 'flex'
        // Время жизни сообщения
        setTimeout(()=>{
            var _toast = document.querySelector(`#${this.toast_uid}`);
            _toast.classList.add('out-slide');
            clearInterval(interval)
            setTimeout(()=>{
                _toast.classList.remove('d-none');
                _toast.classList.add('d-none');
            }, 400);
        }, 15000)

        // Обновление времени создания
        let interval = setInterval(()=>{
            seconds += 5;    
            var _toast = document.querySelector(`#${this.toast_uid}`);
            _toast.querySelector('.form-text').textContent = `${seconds} секунд назад` 
        }, 5000);
    }
}


// Для поддержки функционала закрытия окон, которые создаются с помощью django.messages
function close_toast(btn){
    material_toast = btn.parentNode;
    material_toast.classList.add('out-slide');
    setTimeout(()=>{
        material_toast.classList.remove('d-none');
        material_toast.classList.add('d-none');
    }, 400);
}




