

// Генерация UUID сообщения
function generate_message_UID(){
    var d = new Date().getTime();
    if(window.perfomance && typeof window.performance.now === "function"){
        d += performance.now();
    }
    var uid="message_xxxx-xxxxxxxxx-xxxx".replace(/[x]/g, function(c){
        var r = (d+Math.random()*16) %16|0;
        d = Math.floor(d/16);
        return (c==="x"?r:(r&0x3|0x8.toString(16)));
    })
    return uid;
}

var placeholder_url = 'http://172.18.12.123:8080/chat_api/'

var alert_html_text = "<strong>Сообщение от ИС MU20P</strong>"+
"<button class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">"+
"<span aria-hidden=\"true\">&times;</span>"+
"</button>"

// Глобальный объект для хранения количества промисов, 
// Которые необходимо отправлять на API
const active_promises = {
    count: 0,
    max_count: 1,
    increment(){
        this.count++;
    },
    decrement(){
        this.count--;
    },
    can_create(){
        return this.count< this.max_count;
    }
}

//chat uuid is UUID obj
async function load_chat(chat_uuid, mtr_rid){
    document.querySelector('.messager-container').innerHTML = ''
    const data = await fetch(placeholder_url+'chat/'+chat_uuid+'/')
    .then((response)=>{
        if (response.status !== 200){
            create_chat(placeholder_url, mtr_rid)
        }
        return response.json();
    })
    .then((data)=>{
        fill_chat(data)
        document.querySelector('#current_room').value=data[1][0]['chatroom_id'];
        toast = new MaterialToast("Чат был загружен, теперь вы можете писать сообщения", "bg-success");
        toast.render();
    })
    .catch(err=>{
        console.log(err)
        toast = new MaterialToast("Произошла ошибка загрузки чата, попробуйте еще раз", "bg-danger", 
        `<div><button class="btn btn-outline-dark btn-sm" style="font-size: small;" 
        onclick="load_chat(document.querySelector('#current_chatroom_uid').value,
        document.querySelector('#current_mtr_code').value)">Перезагрузить чат</button></div>`);
        toast.render();
    })
    .finally(()=>{
        document.querySelector('.messager-container').scrollTop = document.querySelector('.messager-container').scrollHeight;
    })

    const mtr_resp = await fetch('/api/mtr/'+mtr_rid+'/', {method:"GET"})
    .then((response)=>{
        return response.json()
    })
    .then((data)=>{
        document.querySelector('#chat_header').innerHTML = 'Переписка по коду МТР '+ data["mtr_code"].toString().padStart(7,"0") +' '+ data["name"] +' '+ data["characteristic"]
    })
    .catch((err)=>{console.log(err)})
}

function fill_chat(data){
    console.log(data[0].length)
    try{
        for(i=0; i<data[0].length; i++){
            create_message(data[0][i])
        }    
    }
    catch(err){
        console.log('Это пустой чат', err)
    }
}

function create_message(data, new_message=false, id=''){
    ymd = data['post_date'].split('T')[0].split('-')
    hmsms = data['post_date'].split('T')[1].slice(0, -1).split(':')
    new_date = new Date(ymd[0], ymd[1], ymd[2], hmsms[0], hmsms[1], hmsms[2].split('.')[0])
    date_str = format_date(new_date)

    html_code = `
        <div id='${id}' class="message ${data['username'] === document.querySelector('#current_user').value?'darker outcoming':'incoming'}">
            <h6>${data['username'] + ' - '+date_str}</h6>
            <p class="text-start">${data['message_text']}</p>
            <span class="d-flex justify-content-end w-100 gap-1">
                ${
                    data['username'] === document.querySelector('#current_user').value
                    ? `<img src="${new_message===true?'/static/svg/time.svg':'/static/svg/check.svg'}" class="img-fluid" width="15" height="15">`
                    : ``
                }
                <small class="text-form">${String(new_date.getHours()).padStart(2, "0") +':'+String(new_date.getMinutes()).padStart(2, "0")}</small>
            </span>
        </div>
    `
    document.querySelector('.messager-container').appendChild(createElFromStr(html_code))
}

// Отправка сообщения
async function post_message(message_text=null){
    if(!active_promises.can_create()){
        console.log("Багулина отловлена ", active_promises.count)
        return;
    }
    var input_mes
    if(message_text===null)
        input_mes = document.querySelector('#message_text').value;
    else
        input_mes = message_text
    
    active_promises.increment();
    // Создание 
    let json_obj = {
        'message_text': input_mes,
        'username': document.querySelector('#current_user').value,
        'post_date': new Date().toISOString(),
        'chatroom': document.querySelector('#current_room').value
    }

    current_id = generate_message_UID()
    create_message(json_obj, true, current_id)

    const requestOptions = {
        method: 'POST',
        headers:{'Content-type':'application/json'},
        body: JSON.stringify(json_obj)
    }

    const response = await fetch(placeholder_url+'add-message/', requestOptions)
    .then((response)=>{
        console.log("promise created")
        return response.json()
    })
    .then((data)=>{
        document.querySelector('#msg-post-btn').classList.add('disabled');
        document.querySelector('#msg-post-btn').classList.add('hidden')
        document.getElementById(current_id).querySelector('img').src = '/static/svg/check.svg'
        toast = new MaterialToast("Сообщение было отправлено", "bg-info");
        toast.render();
    })
    .catch((err)=>{
        console.log("promise err", err)
        document.getElementById(current_id).querySelector('img').src = '/static/svg/chat_error.svg'
        toast = new MaterialToast("Ошибка отправки сообщения. Возможно чат временно недоступен", "bg-warning");
        toast.render();
    })
    .finally(()=>{
        document.querySelector('.messager-container').scrollTop = document.querySelector('.messager-container').scrollHeight;
        document.querySelector('#msg-post-btn').classList.remove('disabled')
        console.log("promise end");
        document.querySelector('#message_text').value = '';
        active_promises.decrement();
    })
}

// Проверка инпута, для показа кнопки
function checkText(input){
    console.log(input.value.length, input.value)
    if(input.value.length == 0){
        document.querySelector('#msg-post-btn').classList.add('hidden')
    }
    else{
        document.querySelector('#msg-post-btn').classList.remove('hidden')
    }
}


// Альтернативный POST метод
function alternative_post(){
    if(event.key === 'Enter'){
        post_message()
    }
}

// Создание чата
function create_chat(chat_api, rid){
    const chat_request_options = {
        method: 'POST',
        headers:{'Content-type':'application/json'},
        body:JSON.stringify({"chatroom_name": "chat_by_rid_"+rid})
    }
    if (rid){
        const chat_response = fetch(chat_api+'chat/', chat_request_options)
        .then((chat_response)=>{
            return chat_response.json()
        })
        .then((data)=>{
            console.log(data["chatroom_uuid"])
            fetch('/api/mtr/'+rid+'/', {
                method: "PUT",
                headers: {'Content-type': 'application/json'},
                body:JSON.stringify({"chatroom_uid": data["chatroom_uuid"]})
            })
            .then((response)=>{return response.json()})
            .then((second_data)=>{
                toast = new MaterialToast("Чат был успешно создан", "bg-success");
                toast.render();
                load_chat(data["chatroom_uuid"], rid);
            })
            .catch((err)=>{
                toast = new MaterialToast("Ошибка сервера. Не удалось создать чат, для данной ревизии кода МТР", "bg-warning");
                toast.render();
            })
        })
        .catch((err)=>{
            toast = new MaterialToast("Приложение чата временно отключено", "bg-warning");
            toast.render();
        })
    }
}


// Форматирование даты
function format_date(date_obj){
    day = date_obj.getDate();
    if (day < 10) day = '0' + day
    mm = date_obj.getMonth();
    if (mm<10) mm ='0'+mm;
    yy = date_obj.getFullYear();
    hh = date_obj.getHours();
    min = date_obj.getMinutes();
    return day + '.' + mm + '.' + yy + ' ' + hh + ':' + min;
}