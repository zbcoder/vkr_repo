var uri_list_length = document.URL.split('/').length;
var uri_list = document.URL.split('/')
var mtr_rid = uri_list[uri_list_length-2]
console.log(mtr_rid)
var approve_url = '/api/approves/'; 
var mtr_url = '/api/mtr/'+mtr_rid+'/';

// 1 - 037, 2 - 055
function put(button, url, id) // role 2 is 055 division placeholder)))
{
    role = document.getElementById('role_id'+id).value
    // button.classList.add('disabled')
    approve_card = button.closest('.card')
    approve_result = approve_card.querySelectorAll('input')
    result = check(approve_result)
    
    switch(role){
        case '1':{
            creator_approval(id, result.value);
            window.location.href = '/approve/list'
            return;
        }
        case '2':{
            supply_department_approval(id, result.value);
            window.location.href = '/approve/list'
            return;
        }
    }
}

//Проверка радиокнопок
function check(approve_result){
    for(var i = 0; i< approve_result.length; i++){
        if(approve_result[i].type=="radio" && approve_result[i].checked){
            return approve_result[i]
        }
    }
    alert('Пожалуйста выберите действие для согласования')
    return
}


// Общий JSON для согласования
function generate_json(approval_id, result){
    return {
        'mtr_rid': mtr_rid,
        'role_id': document.getElementById('role_id'+approval_id).value,
        'ts_approve': new Date().toISOString(),
        'user_approve': document.querySelector("#current_user").value, //placeholder
        'result': result
    }
}

// Новые согласования в формате JSON
function new_approve_by_params(num, division){
    return {
        'mtr_rid': mtr_rid,
        'role_id': 2,
        'ts_create': new Date().toISOString(),
        'user_create': document.querySelector("#current_user").value, 
        'div_no': Number.parseInt(division),
        'num': Number.parseInt(num),
    }
}

// Согласование составителя заявки на код МТР.
function creator_approval(id, approve_result){
    json = generate_json(id, approve_result);
    put_approve(id, json);
}

// Согласование отдел снабжения 
function supply_department_approval(id, approve_result){
    json = generate_json(id, approve_result);
    if(approve_result=='False'){
        new_approves = [];
        new_approves.push(new_approve_by_params(document.querySelector('#first_num').value, document.querySelector('#first_div').value));
        new_approves.push(new_approve_by_params(document.querySelector('#second_num').value, document.querySelector('#second_div').value));
        console.log(new_approves);
        put_approve(id, json);
        post_approve(new_approves);
    }
    else{
        if(document.getElementById('mtr_code'+id).value==0){
            while(true)
            {
                post_value = input_mtr()
                switch(post_value){
                    default: {
                                update_mtr_code(post_value);
                                break;
                            }
                    case null: return;
                    case false: continue; 
                }
                break;
            }
            put_approve(id, json);
        }
        else{
            put_approve(id, json)
        }
    }
}

//request к API на метод PUT для обновления записи
async function put_approve(id, json){
    let full_url = approve_url+id;
    const requestOptions = {
        method: 'PUT',
        headers:{'Content-type':'application/json'},
        body: JSON.stringify(json)
    };
    const response = await fetch(full_url, requestOptions)
    .then((response)=>{
        return response.json();
    })
    .then((data)=>{

    })
    .catch(err=>{

    });
}


// request к API на метод POST для добавления записей при неудачном согласовании 
async function post_approve(json){ 
    const requestOptions = {
        method: 'POST',
        headers:{'Content-type': 'application/json'},
        body: JSON.stringify(json)
    }
    const response = await fetch(approve_url, requestOptions)
    .then((response)=>{
        return response.json();
    })
    .then((data)=>{
        console.log(data)
    })
    .catch((err)=>{
        console.log(err);
    });
}

// request к API method:PUT upd mtrcode
async function update_mtr_code(mtr_counter){
    let sections = location.url;

    full_mtr = document.getElementById('mtr_code_pattern').value + mtr_counter.padStart(4, '0');
    let mtr_code_upd_json = {
        'mtr_code': full_mtr,
        'um_code': document.getElementById('mtr_um').value
    };

    const requestOptions = {
        method: 'PUT',
        headers:{'Content-type':'application/json'},
        body: JSON.stringify(mtr_code_upd_json)
    }
    const response = await fetch(mtr_url, requestOptions)
    .then((response)=>{

        return response.json();
    })
    .then((data)=>{

    })
    .catch((err)=>console.log(err));
}

function input_mtr(){
    post_value = prompt('Введите счетчик кода МТР');
    regex = /^[0-9]+$/g
    if(post_value == null){  
        alert('Действие отменено пользователем')
        return null;
    }
    else{
        if(regex.test(post_value) && parseInt(post_value)<9999 && parseInt(post_value)>0){
            return post_value;
        }
        else
        {
            alert('Неверный ввод');
            return false;
        }
    }
}


function validate_mtr_input(input){
    console.log(input.value)
    small = document.querySelector('#validator_mtr_code')
    if (!(/^[0-9]+$/).test(input.value))
    {
        small.innerHTML = 'Введено не целое число'
        document.querySelector('#approve_btn').classList.add('disabled')
        small.style.color='#EA4B00'
    }
    else if (input.value < 0 ||input.value > 9999 ){
        small.innerHTML = 'Вами введено число '+input.value+' ограничение счетчика кода МТР от 0 до 9999'
        document.querySelector('#approve_btn').classList.add('disabled')
        small.style.color='#EA4B00'
    }
    else{
        small.innerHTML = 'Число соответствует требованиям'
        input.value = (input.value).padStart(4, '0')
        document.querySelector('#approve_btn').classList.remove('disabled')
        small.style.color='#009D66'
    }
}