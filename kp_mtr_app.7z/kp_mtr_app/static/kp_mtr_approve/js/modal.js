var modal = document.querySelector('.modal-custom');
var cancel_button = document.querySelector('#cancel-button');
var confirm_button = document.querySelector('#confirm-button');
var exit_button = document.querySelector('#close-btn');
var input = document.getElementById('new_mtr_code');
var error_text = document.querySelector('#error_text'); 
var overlay = document.querySelector('.overlay');

console.log(modal)

function show(){   
    modal.classList.remove("hidden");
    overlay.classList.remove('hidden')
}

function close_modal(){
    modal.classList.add("hidden");
    error_text.classList.add("hidden")
    overlay.classList.add('hidden')
    input.value = ""
    return false
}

cancel_button.addEventListener("click", close_modal);

//Функция для утверждения условного кода МТР
confirm_button.addEventListener("click", ()=>{   
    if (input.value.length>4 )
    {
        error_text.innerHTML = 'Счетчик кода МТР должен не больше 4 цифр! Допустимые значения счетчика 1 - 9999'
        error_text.classList.remove("hidden")
    }
    else if(input.value.replace(/\d/g, '').length)
    {
        error_text.innerHTML = 'Введены не только цифры'
        error_text.classList.remove("hidden")
    }
    else{
        console.log(input.value)
        update_mtr_code(input.value)
    }
})
