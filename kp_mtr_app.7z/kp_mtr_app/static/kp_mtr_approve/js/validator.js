alert_html_text = "<strong>Сообщение от ИС MU20P</strong>"+
"<button class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">"+
"<span aria-hidden=\"true\">&times;</span>"+
"</button>"

async function create_toast(text){
    toast = document.createElement('div')
    toast.classList.add("alert")
    toast.classList.add("alert-info")
    toast.innerHTML = alert_html_text + '<p class=\"form-text\">'+toast_str+"</p>"
    document.querySelector(".toasts-container").appendChild(toast)
    setTimeout(() => {
        alert_list = document.querySelectorAll('.alert')
        alert_list.forEach(function(alert){
            alert.classList.add('fade')
            alert.classList.add('in')
            })
    }, 5000);
}

function ch_characteristics(input, template){
    const reg = RegExp(template);
    var current_input = input.closest('td');
    small = current_input.querySelector('p');
    if(reg.test(input.value)){ 
        // small.innerHTML='Значение соответствует шаблону';
        // small.style.color='rgb(24, 135, 5)';
        document.getElementById("post-btn").classList.remove("disabled");
    }
    else
    {
        small.style.color='rgb(248, 58, 58)';
        small.innerHTML='Введите значение по шаблону: '+template;
        document.getElementById("post-btn").classList.add("disabled");
    }
    if (input.value == '')
    {
        small.style.color='rgb(248, 58, 58)';
        small.innerHTML='';
        document.getElementById("post-btn").classList.remove("disabled");
    }   
}

