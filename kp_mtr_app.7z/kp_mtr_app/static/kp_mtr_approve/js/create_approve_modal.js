// USES IN CREATE_APPROVE.HTML TEMPLATE

var overlay = document.querySelector('.overlay');
console.log(overlay)
var modal_window = document.querySelector('#confirm_action');

// events initializate
document.querySelector('#post-btn').addEventListener("click", show_confirm_dialog)
document.querySelector('#cancel-btn').addEventListener("click", hide_confirm_dialog)
document.addEventListener('keydown', is_escape_key)
overlay.addEventListener("click", hide_confirm_dialog)

// Show window
function show_confirm_dialog(){
    modal_window.classList.remove('d-none');
    document.querySelector('.overlay').classList.toggle('d-none');
}

// Close window
function hide_confirm_dialog(){
    modal_window.classList.add('d-none');
    document.querySelector('.overlay').classList.toggle('d-none');
}

// Key press check
function is_escape_key(e){
    if (e.keyCode === 27) {
        hide_confirm_dialog();
    }
}