var mtr_code_pattern_for_input = "0";

function checkEnter(e){
    if (e.keyCode == 13){
        return false;
    }
}

function checkMtrEnter(e){
    if (e.keyCode==13){
        return false;
    }
}

function edit_mtrcode(btn_click){
    let input = document.querySelector('#mtr_code') 
    let img = document.querySelector('#mtrcode_img')
    console.log(img.src)
    if(input.disabled===false){
        input.disabled=true
        img.src = '/static/svg/edit.svg'
    }
    else{
        input.disabled=false
        img.src = '/static/svg/check.svg'
    }
}

function edit_mtrcode__default_state(){
    let input = document.querySelector('#mtr_code')
    let img = document.querySelector('#mtrcode_img')
    input.disabled=true
    img.src='/static/svg/edit.svg' 
}

function get_fields_by_mtr_group(selectObject, isnew=true){
    var mtr_code_pattern = selectObject.value;
    fetch('/api/characteristic_fields/'+mtr_code_pattern)
    .then(function(response){
        return response.json()
    })
    .then(function (data){
        console.log(data)
        document.getElementById('supply_group_id').value = data['json'][0]['supply_group_id']
        document.getElementById('mtr_group').value = data['json'][0]['mtr_group_id']
        mtr_code_pattern_for_input = mtr_code_pattern.padStart(3, "0");
        if (isnew===true)
            document.getElementById("mtr_code").value = data['ff_mtrcode'].toString().padStart(7, "0");
            edit_mtrcode__default_state()
            // if(document.getElementById("mtr-code-cb").checked)
        //     document.getElementById('mtr_code').value = mtr_code_pattern.padStart(3, "0");
        console.log(data)
        fill_table(data)
    })
    .catch(function(err){
        console.warn('Some went wrong ', err)
    })
}

function fill_table(data){
    clear_table();
    //create mainly parts of table
    var thead = document.createElement('thead')
    var tbody = document.createElement('tbody')
    thead.classList.add('w-100')
    tbody.classList.add('w-100')
    thead.id='thead'
    tbody.id='tbody'
    //create table headers
    var th_text_value = document.createTextNode('Характеристика')
    var th_text_field_name = document.createTextNode('Значение')
    var th_value = document.createElement('th')
    var th_field_name = document.createElement('th')
    //append th_nodes to th
    th_value.appendChild(th_text_value)
    th_field_name.appendChild(th_text_field_name)
    //append th to thead
    thead.appendChild(th_value)
    thead.appendChild(th_field_name)
    //create and fill tbody
    for (var i=0; i < data['json'].length; i++){
        var tr = document.createElement('tr')
        var td_field_name = document.createElement('td')
        var td_input = document.createElement('td')
        var td_input_value = document.createElement('input')
        var small = document.createElement('small');
        var p = document.createElement('p');
        p.classList.add('text-break');
        small.appendChild(p);
        small.classList.add('text-break');
        small.classList.add('fw-lighter');
        td_input.id="sgf"+data['json'][i]['supply_group_field_id']
        td_input_value.setAttribute("onkeypress", "return checkEnter(event)")
        td_field_name.classList.add("col-md-2")
        td_input.classList.add("col-md")
        td_input_value.setAttribute('onchange', 'ch_characteristics(this, \''+data['json'][i]['template']+'\')');
        var td_hidden_field_name = document.createElement('input')
        var _supply_group_field_input = document.createElement('input')

        _supply_group_field_input.type='hidden'
        _supply_group_field_input.name='supply_group_field_id'
        _supply_group_field_input.value=data['json'][i]['supply_group_field_id']

        td_hidden_field_name.type = 'hidden'
        td_input_value.type = 'text';

        td_input_value.classList.add('form-control');
        // td_input_value.classList.add('form-control-sm');
        td_input_value.placeHolder = 'Введите значение поля'
        td_text_field_name = document.createTextNode(data['json'][i]['field_name'])


        td_input_value.name='field_value[]'
        td_hidden_field_name.name='field_id[]'
        td_hidden_field_name.value = data['json'][i]['field_id']


        td_input.appendChild(td_input_value);
        td_input.appendChild(small);
        td_field_name.appendChild(td_text_field_name)

        tr.appendChild(td_hidden_field_name)
        tr.appendChild(td_field_name)
        tr.appendChild(td_input)
        tr.appendChild(_supply_group_field_input)
        tbody.appendChild(tr)
    }
    f_value = data["json"][0]
    console.log(f_value)
    document.querySelector('#mtr_supply_group_info').innerHTML = `Группа снабжения ${f_value["div_no"]} ${f_value["code"]}
     ${f_value["supply_group_name"]}`
    document.getElementById('mtr_group_fields').appendChild(thead);
    document.getElementById('mtr_group_fields').appendChild(tbody);
    document.querySelector('#mtr_group_fields').classList.remove('d-none');
    //append thead and tbody to HTML table
}

function clear_table(){
    try{
        document.getElementById('mtr_group_fields').removeChild(document.getElementById('thead'));
        document.getElementById('mtr_group_fields').removeChild(document.getElementById('tbody'));
    }
    catch{
        console.log('empty')
    }
}

function ch_mtrcode(input){
    console.log(input.value)
    if(input.value.substr(0,3)!=mtr_code_pattern_for_input){
        document.getElementById("mtr_code_error").innerHTML = "Неверный ввод. Первые 3 цифры кода МТР должны быть "+mtr_code_pattern_for_input;
        document.getElementById("post-btn").classList.add("disabled");
        return;
    }
    else if(isNaN(input.value)){
        document.getElementById("mtr_code_error").innerHTML="В коде МТР могут присутствовать только цифры от 0-9";
        document.getElementById("post-btn").classList.add("disabled");
        return
    }
    else if(input.value.length<7 || input.value.length>7){
        document.getElementById("mtr_code_error").innerHTML="В коде МТР может быть максимум 7 символов";
        document.getElementById("post-btn").classList.add("disabled");
        return
    }  
    else{
        document.getElementById("mtr_code_error").innerHTML="";
        document.getElementById("post-btn").classList.remove("disabled");
    }
    
    const response = fetch('/api/name_by_mtrcode/'+Number(document.getElementById("mtr_code").value).toString())
    .then((response)=>{
        return response.json()
    })
    .then((data)=>{  
        if (data["data"].length == 0)
            document.getElementById("mtr_name").value = ""
        else{
            document.getElementById("mtr_name").value = data["data"][0]["name"]
            data["mtf_qs"].forEach((elem)=>{
                let parent = document.querySelector('#sgf'+elem["supply_group_field"])
                parent.querySelector("input").value = elem["value"]
            })
            document.querySelector('#um_code').selectedValue=data["data"][0]["um_code"]
            toast_str = `Для кода МТР ${String(data["data"][0]["mtr_code"]).padStart(7,'0')} найдено наименование - ${data["data"][0]["name"]}. 
            Характеристика кода МТР: ${data["data"][0]["name"] +" "+ data["data"][0]["characteristic"]}`
            console.log(data["data"][0]) 
            toast = new MaterialToast(toast_str, "bg-info");
            toast.render();
            document.querySelector('#mtr_group_template').value = data["group_info"]["mtr_code_pattern"]
            document.querySelector('#um_code').value = data["data"][0]["um_code"]
            // get_fields_by_mtr_group(document.querySelector('#mtr_group_template'), isnew = false);
        }
    })
    .catch((err)=>{
        console.log(err)
    });
}

function fill_from_data(data){
    
}