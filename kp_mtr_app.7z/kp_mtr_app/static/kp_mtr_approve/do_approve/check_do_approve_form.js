function check_do_approve_form(e){
    let input = document.querySelector("#cancel-justification")
    if(document.querySelector('#confirm_action').classList.contains('d-none'))
        return true;
    else if (input.value.length<7){
        e.preventDefault();
        check_do_approve_input();
        return false;
    }
    else{
        let msg_text = input.value
        post_message(msg_text)
        return true;
    }
}

function check_do_approve_input(){
    let input = document.querySelector("#cancel-justification")
    if(input.value.length<7){
        document.querySelector('#cancel-justification-text').classList.remove('d-none')
    }
    else
        document.querySelector('#cancel-justification-text').classList.add('d-none')
}