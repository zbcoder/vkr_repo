
var show_btn = document.querySelector('#price_edit_btn');
var overlay = document.querySelector('.modal-custom-overlay');
var cancel_btn = document.querySelector('#supply_group_cancel_button');


show_btn.addEventListener('click', modal_show);
cancel_btn.addEventListener('click', modal_close);
overlay.addEventListener('click', modal_close);


function modal_show(){
    document.querySelector('.modal-custom-overlay').classList.remove('hidden');
    document.querySelector('#select_mtr_group').classList.remove('hidden');
}

function modal_close(){
    document.querySelector('.modal-custom-overlay').classList.add('hidden');
    document.querySelector('#select_mtr_group').classList.add('hidden');
}