tmp_uri = '/api/update_characteristic/'

async function update_characteristics(api_url){
    table = document.querySelector("#characteristic_table")
    tr_arr = table.querySelectorAll('tr')

    for(i=1; i< tr_arr.length; i++){
        console.log(tr_arr[i].querySelector("#characteristic_value").value)
        current_value = tr_arr[i].querySelector("#value_id").value
        const headers = {
            method: 'PUT',
            headers:{'Content-type':'application/json'},
            body: JSON.stringify({
                'value': tr_arr[i].querySelector("#characteristic_value").value
            })
        };
        const response = await fetch(tmp_uri+current_value, headers)
        .then((response)=>{return response.json()})
        .then((data)=>{console.log(data)})
        .catch((err)=>{console.log(err)})      
    }
        document.querySelector('#post-characteristics-btn').classList.add('hidden');
        document.querySelectorAll('#text-validator').forEach((e)=>{
        e.classList.add('hidden')
    });
    toast_text = "Характеристики кода МТР, были успешно обновлены."
    toast = new MaterialToast(toast_text, "bg-success");
    toast.render();
}