


const createElFromStr = (str) => { return new Range().createContextualFragment(str)}
// ДЛЯ СОСТАВЛЕНИЯ ИСТОРИИ ЦЕН ИСПОЛЬЗУЕТСЯ modal__create_price_history.js

var modal = document.querySelector('.modal-bottom');
var exit_button = document.querySelector('#close-btn');
var overlay = document.querySelector('.overlay');
var table = document.querySelector('#characteristic_table');
console.log(modal)

const input_classes = ["form-control", "form-control-sm"]

function show_bottom_modal(){   
    modal.classList.remove("hidden");
    overlay.classList.remove('hidden')
}

function close_bottom_modal(){
    modal.classList.add("hidden");
    overlay.classList.add('hidden')
    while(table.firstChild){
        table.removeChild(table.firstChild);
    }
    return false
}

exit_button.addEventListener("click", close_bottom_modal);

document.addEventListener('keydown', check_modal)
function check_modal(e){
    if (e.keyCode === 27) {
        close_modal()
        close_bottom_modal()
    }
}


document.addEventListener('click', function(e){
    if(e.target.className == 'overlay'){
        close_bottom_modal()
        close_modal()
    }   
})

//Стандартное модальное окно
var supply_group_modal = document.querySelector('.modal-custom');
var exit_button = document.querySelector('#supply-close-btn');
var supply_group_cancel_button = document.querySelector('#supply_group_cancel_button')
// Не придумал как сделать иначе, поэтому буду вставлять код, для каждого отдельного случая
// 1. Группы МТР
var mtr_groups_header = 'Выбор Категории МТР'

// 2. Цена 
var price_modal_header = 'Цена МТР'

// 3. Стратегический запас
var str_store_header = 'Стратегический запас'

// 4. Транзитная норма
var tr_norm_header = 'Транзитная норма'

// 5. GID
var gid_header = 'Заведение GID для МТР' 

// 6. Another header
var another_fields_header = 'Заведение дополнительных данных'

document.querySelector('#open_supply_modal').addEventListener('click', function(){show_modal(this)})
exit_button.addEventListener('click', close_modal)
supply_group_cancel_button.addEventListener('click', close_modal)
document.querySelector('#price_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#str_store_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#tr_norm_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#gid_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#another_field_btn').addEventListener('click', function(){show_modal(this)})


function show_modal(draw_style){
    document.querySelector('#diff_modal').innerHTML = ''
    draw_arg = draw_style.getAttribute("value")
    console.log(draw_arg)
    draw(draw_arg)
    supply_group_modal.classList.remove('hidden')
    document.querySelector('.modal-custom-overlay').classList.remove('hidden')
}

function close_modal(){
    supply_group_modal.classList.add('hidden')
    document.querySelector('.modal-custom-overlay').classList.add('hidden')
}

document.querySelector('.modal-custom-overlay').addEventListener('click', close_modal)

// отрисовка Модального окна
function draw(value_param){
    switch(value_param){
        case 'groups':{
            document.querySelector('#custom_modal_header').innerHTML = mtr_groups_header
            construct_groups_form()
            break;
        }
        case 'price':{
            document.querySelector('#custom_modal_header').innerHTML = price_modal_header
            construct_price_form()
            break;
        }
        case 'str_store':{
            document.querySelector('#custom_modal_header').innerHTML = str_store_header
            construct_str_store()
            break;
        }
        case 'tr_norm':{
            document.querySelector('#custom_modal_header').innerHTML = tr_norm_header
            construct_tr_norm()
            break;
        }
        case 'gid':{
            document.querySelector('#custom_modal_header').innerHTML = gid_header
            construct_gid()
            break;
        }
        case 'another':{
            document.querySelector('#custom_modal_header').innerHTML = another_fields_header
            construct_another_fields()
            break;
        }
    };
}

// Внешний вид формы групп снабжения
async function construct_groups_form(){

    document.querySelector('#multiply-actions-form').method="GET"
    document.querySelector('#multiply-actions-form').action="#"
    const response = await fetch('/api/supply_groups')
    .then(response=>{
        return response.json()
    })
    .then(data=>{
        html_code = `
        <label for="supply_group_filter" class="form-label">Выберите категорию из списка</label>
        <select id="supply_group_filter" class="form-select" name="supply_group">
            <option value="">-------------------ИСКАТЬ ВСЮДУ----------------</option>
            ${data.map(elem=>`<option value=${elem['supply_group_id']}>${elem['div_no']} ${elem['code']} ${elem['name']}</option>`).join("")}
        </select>
    `
    document.querySelector('#diff_modal').appendChild(createElFromStr(html_code))
    })
    
    // label = document.createElement('label')
    // label.for = 'supply_group_filter'
    // label.classList.add('form-label')
    // label.innerHTML = "Выберите категорию из списка"
    // select = document.createElement('select')
    // select.classList.add('form-select')
    // select.id = 'supply_group_filter'
    // console.log(document.querySelector('.diff_modal'))
    // document.querySelector('#diff_modal').appendChild(label)
    // document.querySelector('#diff_modal').appendChild(select)
}

function construct_price_form(){
    // Добавить таблицу для просмотра старых цен
    mtr_code = document.createElement('input')
    mtr_code.type='hidden'; mtr_code.value=document.querySelector('#current_mtr_code').value; mtr_code.name='mtr_code';
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_price'
    row = document.createElement('div')
    col_pr=document.createElement('div');col_st_date=document.createElement('div');
    col_pr_descr=document.createElement('div');row.classList.add('row');
    pr_label=document.createElement('label');date_label=document.createElement('label');descr_label=document.createElement('label');
    pr_input=document.createElement('input');date_input=document.createElement('input');descr_input=document.createElement('input');
    date_input.type='date'; pr_input.type='number'; pr_input.step = 0.01;
    pr_input.name='price';date_input.name='price_start_date';descr_input.name='price_justification';
    pr_label.classList.add('form-label'); date_label.classList.add('form-label'); descr_label.classList.add('form-label');
    pr_label.innerHTML='Новая цена'; date_label.innerHTML='Начало действие цены';descr_label.innerHTML='Обоснование цены';
    pr_input.classList.add(...input_classes); date_input.classList.add(...input_classes);descr_input.classList.add(...input_classes);
    col_pr.appendChild(pr_label);col_pr.appendChild(pr_input);
    col_st_date.appendChild(date_label);col_st_date.appendChild(date_input);
    col_pr_descr.appendChild(descr_label);col_pr_descr.appendChild(descr_input);
    col_pr.classList.add('col-md-4'); col_st_date.classList.add('col-md-8'); col_pr_descr.classList.add('col-md-12');
    row.appendChild(col_pr); row.appendChild(col_st_date); row.appendChild(col_pr_descr);
    document.querySelector('#diff_modal').appendChild(row);document.querySelector('#diff_modal').appendChild(mtr_code);
}

function construct_str_store(){
    // Добавить таблицу для просмотра старых обоснований стратегического запаса
    mtr_rid = document.createElement('input'); mtr_rid.type='hidden'; mtr_rid.value = document.querySelector('#current_rid').value; mtr_rid.name='mtr_rid';
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_str_store'
    str_label=document.createElement('label');str_input=document.createElement('input'); str_input.name='strategic_reserve_justification'
    str_description=document.createElement('small');
    str_label.classList.add('form-label');str_input.classList.add(...input_classes);
    str_label.innerHTML='Введите обоснование стратегического запаса';
    str_description.innerHTML='Чтобы убрать признак стратегического запаса нужно сохранить пустое обоснование';
    str_description.classList.add('form-text');str_description.classList.add('text-muted');
    document.querySelector('#diff_modal').appendChild(str_label);document.querySelector('#diff_modal').appendChild(str_input);
    document.querySelector('#diff_modal').appendChild(str_description);document.querySelector('#diff_modal').appendChild(mtr_rid);
}

function construct_tr_norm(){
    // Добавить таблицу для просмотра старых транзитных норм для кода МТР
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_tr_rate'
    rid = document.createElement('input'); rid.name='mtr_rid'; rid.type='hidden';rid.value = document.querySelector('#current_rid').value;
    row=document.createElement('div');col_4=document.createElement('div');col_8=document.createElement('div');
    row.classList.add('row');col_4.classList.add('col-md-4');col_8.classList.add('col-md-8');
    tr_norm_label=document.createElement('label');tr_norm_input=document.createElement('input');
    tr_norm_descr=document.createElement('label');tr_norm_descr_input=document.createElement('input');
    tr_norm_input.name='transit_rate'; tr_norm_descr_input.name='transit_rate_justification';
    tr_norm_label.innerHTML='Новая транзитная норма';tr_norm_descr.innerHTML='Обоснование транзитной нормы'
    tr_norm_label.classList.add('form-label');tr_norm_descr.classList.add('form-label');
    tr_norm_input.classList.add(...input_classes);tr_norm_descr_input.classList.add(...input_classes);
    col_4.appendChild(tr_norm_label);col_4.appendChild(tr_norm_input);
    col_8.appendChild(tr_norm_descr);col_8.appendChild(tr_norm_descr_input);
    row.appendChild(col_4);row.appendChild(col_8);
    document.querySelector('#diff_modal').appendChild(rid); document.querySelector('#diff_modal').appendChild(row);
}

function construct_gid(){
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_gid'
    mtr_rid = document.createElement('input'); mtr_rid.type='hidden'; mtr_rid.name="mtr_rid"; mtr_rid.value = document.querySelector('#current_rid').value;
    gid_label = document.createElement('label'); gid_input = document.createElement('input'); gid_input.type="number";
    gid_input.name='gid';
    gid_label.classList.add('form-label');gid_input.classList.add(...input_classes);
    gid_label.innerHTML="Введите новый GID";
    document.querySelector('#diff_modal').appendChild(mtr_rid);
    document.querySelector('#diff_modal').appendChild(gid_label);document.querySelector('#diff_modal').appendChild(gid_input);
}

function construct_another_fields(){
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_another_fields'
    html_code = `
        <input type="hidden" value="${document.querySelector('#current_rid').value}" name="mtr_rid"/>
        <div class="input-group mt-2">
            <input type="checkbox" id="okpd2_code" class="form-check-input" onchange='change_check(this)'/>
            <input type="number" name="okpd2_code" class="form-control form-control-sm fs-6" placeholder="Код ОКПД2" disabled/>
        </div>
        <div class="input-group mt-2">
            <input type="checkbox" id="ekps_code" class="form-check-input" onchange='change_check(this)' />
            <input type="number" name="ekps_code" class="form-control form-control-sm fs-6" placeholder="Код ЕКПС" disabled/>
        </div>
        <div class="input-group mt-2">
            <input type="checkbox" id="fnn_code" class="form-check-input" onchange='change_check(this)' />
            <input type="number" name="fnn_code" class="form-control form-control-sm fs-6" placeholder="Код ФНН" disabled/>
        </div>
        <div class="input-group mt-2">
            <input type="checkbox" id="who_otch" class="form-check-input" onchange='change_check(this)'/>
            <input type="text" name="who_responsible" class="form-control form-control-sm fs-6" placeholder="Ответственный за код МТР" disabled/>
        </div>
    `
    document.querySelector('#diff_modal').innerHTML = html_code;    
}

function change_check(nodeElem){
    let form = nodeElem.closest('div')
    let input = form.querySelector('form-control .form-control-sm');
    console.log(input)
    input.disabled = !nodeElem.checked
}


// Описание таблицы для показа цены