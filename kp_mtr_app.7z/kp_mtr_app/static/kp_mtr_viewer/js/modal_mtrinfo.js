// const createElFromStr = (str) => { return new Range().createContextualFragment(str)}
// ДЛЯ СОСТАВЛЕНИЯ ИСТОРИИ ЦЕН ИСПОЛЬЗУЕТСЯ modal__create_price_history.js

var supply_group_modal = document.querySelector('.modal-custom');
var exit_button = document.querySelector('#supply-close-btn');
var supply_group_cancel_button = document.querySelector('#supply_group_cancel_button')
// Не придумал как сделать иначе, поэтому буду вставлять код, для каждого отдельного случая
// 1. Группы МТР
var mtr_groups_header = 'Выбор Категории МТР'

// 2. Цена 
var price_modal_header = 'Изменение цены кода МТР'

// 3. Стратегический запас
var str_store_header = 'Изменение стратегического запаса'

// 4. Транзитная норма
var tr_norm_header = 'Изменение транзитной нормы'

// 5. GID
var gid_header = 'Изменение GID для кода МТР' 

// 6. Другие параметры ОКПД2, ЕКПС, ФНН
var another_fields_header = 'Заведение дополнительных данных кода МТР'

exit_button.addEventListener('click', close_modal)
supply_group_cancel_button.addEventListener('click', close_modal)
document.querySelector('#price_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#str_store_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#tr_norm_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#gid_edit_btn').addEventListener('click', function(){show_modal(this)})
document.querySelector('#another_field_btn').addEventListener('click', function(){show_modal(this)})

function show_modal(draw_style){
    document.querySelector('#diff_modal').innerHTML = ''
    draw_arg = draw_style.getAttribute("value")
    console.log(draw_arg)
    draw(draw_arg)
    supply_group_modal.classList.remove('hidden')
    document.querySelector('.modal-custom-overlay').classList.remove('hidden')
}

function close_modal(){
    supply_group_modal.classList.add('hidden')
    document.querySelector('.modal-custom-overlay').classList.add('hidden')
    let footer = document.querySelector('.modal-end')
    console.log(footer)
    if (footer.contains(document.querySelector('.btn-outline-info'))){
        document.querySelector('.btn-outline-info').remove()
    } 
}

document.querySelector('.modal-custom-overlay').addEventListener('click', close_modal)

// отрисовка Модального окна
function draw(value_param){
    switch(value_param){
        case 'groups':{
            document.querySelector('#custom_modal_header').innerHTML = mtr_groups_header
            construct_groups_form()
            break;
        }
        case 'price':{
            document.querySelector('#custom_modal_header').innerHTML = price_modal_header
            get_price_history(document.querySelector('#current_mtr_code').value)
            construct_price_form()
            break;
        }
        case 'str_store':{
            document.querySelector('#custom_modal_header').innerHTML = str_store_header
            construct_str_store()
            break;
        }
        case 'tr_norm':{
            document.querySelector('#custom_modal_header').innerHTML = tr_norm_header
            construct_tr_norm()
            break;
        }
        case 'gid':{
            document.querySelector('#custom_modal_header').innerHTML = gid_header
            construct_gid()
            break;
        }
        case 'another':{
            document.querySelector('#custom_modal_header').innerHTML = another_fields_header
            construct_another_fields()
            break;
        }
    };
}


// Внешний вид формы групп снабжения

function construct_form_from_template(html_code){
    document.querySelector('#diff_modal').appendChild(createElFromStr(html_code))
}

function construct_groups_form(){
    html_code = `
        <label for="supply_group_filter" class="form-label">Выберите категорию из списка</label>
        <secect id="supply_group_filter" class="form-select">
            <option>Категория</option>
        </secect>
    `
    document.querySelector('#diff_modal').appendChild(createElFromStr(html_code))
}


// ШАБЛОН ДЛЯ ИЗМЕНЕНИЯ УДАЛЕНИЯ ЦЕНЫ
function construct_price_form(){
    // Добавить таблицу для просмотра старых цен
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_price'
    html_code = `
        <div id="price_edit_container" class="gap-3">
            <div class="row gap-3">
                <input type="hidden" name="mtr_code" value="${document.querySelector('#current_mtr_code').value}"/>
                <div class="col-md-4 col-sm-6">
                    <input type="number" class="form-control fs-5" placeholder="Введите цену..." name="price"/>
                </div>
                <div class="col-sm col-md">
                    <input type="date" class="form-control fs-5" name="price_start_date"/>
                </div>
            </div>
            <div class="row mt-1">
                <div class="col">
                    <input class="form-control fs-5" name="price_justification" placeholder="Введите обоснование цены..."/>
                </div>
            </div>
        </div>
        
    `
    // ДОБАВЛЕНИЕ ФУНКЦИОНАЛА СМЕНЫ ОТОБРАЖЕНИЯ ОКНА
    show_history_btn = `
        <button type="button" id="history_price_btn" class="btn btn-outline-info justify-self-end">Посмотреть историю</button>
    `
    document.querySelector('.modal-end').appendChild(createElFromStr(show_history_btn))
    document.querySelector('#history_price_btn').addEventListener('click', (e)=>{
        document.querySelector('#price_edit_container').classList.toggle('d-none');
        document.querySelector('#price_table').classList.toggle('d-none');
        document.querySelector('#price_table').classList.contains('d-none')?e.target.textContent='Посмотреть историю':e.target.textContent='Закрыть историю'
    })
    document.querySelector('#diff_modal').appendChild(createElFromStr(html_code))
}

// ШАБЛОН ДЛЯ ИЗМЕНЕНИЯ/ДОБАВЛЕНИЯ СТРАТЕГИЧЕСКОГО ЗАПАСА
function construct_str_store(){
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_str_store'
    html_code = `
        <div id="price_edit_container" class="gap-3">
            <input type="hidden" name="mtr_rid" value="${document.querySelector('#current_rid').value}"/>
            <input placeholder="Введите обоснование стратегического запаса" name="strategic_reserve_justification" class="form-control fs-5" value="${document.querySelector('#current_str_store').value==='None'?'': document.querySelector('#current_str_store').value}"/>
            <small class="text-form text-muted fs-6">Чтобы убрать признак стратегического запаса, нужно сохрнанить пустое обоснование</small>
        </div>
    `
    document.querySelector('#diff_modal').appendChild(createElFromStr(html_code))
}

// ШАБЛОН ДЛЯ И/У ТРАНЗИТНОЙ НОРМЫ
function construct_tr_norm(){
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_tr_rate'
    html_code = `
        <div class="row">
            <input type="hidden" value="${document.querySelector('#current_rid').value}" name="mtr_rid"/>
            <div class="col-md-4">
                <input class="form-control fs-5" type="number" name="transit_rate" placeholder="Новое значение транзитной нормы"
                value="${document.querySelector('#transit_norm').value==='None'?'': document.querySelector('#transit_norm').value}"/>
            </div>
            <div class="col">
                <input class="form-control fs-5" name="transit_rate_justification" placeholder="Обоснование транзитной нормы"
                value="${document.querySelector('#transit_norm_justification').value==='None'?'': document.querySelector('#transit_norm_justification').value}"/>
            </div>
            <small class="text-form text-muted fs-6">Чтобы убрать признак транзитной, нормы нужно сохрнанить пустое обоснование</small>
        </div>
    `
    document.querySelector('#diff_modal').appendChild(createElFromStr(html_code))
}

function construct_gid(){
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_gid' 
    html_code = `
        <div class="row col">
            <input type="hidden" name="mtr_rid" value="${document.querySelector('#current_rid').value}"/>
            <input type="number" class="form-control fs-5" name="gid" placeholder="Введите значения для кода GID"
            value="${document.querySelector('#gid_code').value==='None'?'': document.querySelector('#gid_code').value}"/>
            <small class="text-form text-muted fs-6">Чтобы убрать признак GID, нужно сохрнанить пустое обоснование</small>
        </div>
    `
    document.querySelector('#diff_modal').appendChild(createElFromStr(html_code))
}

function construct_another_fields(){
    document.querySelector('#multiply-actions-form').action = 'form_actions/update_another_fields'
    html_code = `
        <input type="hidden" value="${document.querySelector('#current_rid').value}" name="mtr_rid"/>
        
        <div class="input-group mt-2">
            <span class="input-group-text" for="okpd2_input" style="width:150px;">ОКПД2 Код</span>
            <input type="number" id="okpd2_input" name="okpd2_code" class="form-control fs-5" placeholder="Код ОКПД2" 
            value="${document.querySelector('#okpd2').value==='None'?'': document.querySelector('#okpd2').value}"/>
        </div>
        
        <div class="input-group mt-2">
            <span class="input-group-text text-center" for="ekps_input" style="width:150px;">ЕКПС Код</span>    
            <input type="number" id="ekps_input" name="ekps_code" class="form-control fs-5" placeholder="Код ЕКПС"
                value="${document.querySelector('#ekps').value==='None'?'': document.querySelector('#ekps').value}"/>
        </div>
       
        <div class="input-group mt-2">
            <span class="input-group-text text-center" for="fnn_input" style="width:150px;">ФНН Код</span>
            <input type="number" id="fnn_input" name="fnn_code" class="form-control fs-5" placeholder="Код ФНН"
                value="${document.querySelector('#fnn').value==='None'?'': document.querySelector('#fnn').value}"/>
        </div>
        
        <div class="input-group mt-2">
            <span class="input-group-text text-center" for="who_responsible_input" style="width:150px;">Ответственный</span>
            <input type="text" id="who_responsible_input" name="who_responsible" class="form-control fs-5" placeholder="Ответственный за код МТР"
                value="${document.querySelector('#who_responsible').value==='None'?'': document.querySelector('#who_responsible').value}"/>
        </div>
        
    `
    document.querySelector('#diff_modal').innerHTML = html_code;    
}


// Изменение состояния флажков another_fields

function change_check(nodeElem){
    let form = nodeElem.closest('div')
    let input = form.querySelector('.form-control');
    input.disabled = !nodeElem.checked
}

