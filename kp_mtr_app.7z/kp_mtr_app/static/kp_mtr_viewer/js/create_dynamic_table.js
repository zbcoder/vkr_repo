
function add_str(table_name){
    cur_table = document.getElementById(table_name); //it's current table
    tr = document.createElement('tr');
    td = document.createElement('td');
    sec_td =document.createElement('td');
    input=document.createElement('input')
    td2_text = document.createTextNode('tmp');

    input.appendChild(td2_text)
    input.name='param_value'
    input.style = 'width: 100%'
    sec_td.appendChild(input);
    tr.appendChild(td);
    tr.appendChild(sec_td);
    new_select = document.createElement('select');
    //допустим 3
    f_select = document.createElement('option')
    s_select = document.createElement('option')
    th_select = document.createElement('option')
    f_select_text = document.createTextNode('1')
    s_select_text = document.createTextNode('2')
    th_select_text = document.createTextNode('3')
    f_select.appendChild(f_select_text)
    s_select.appendChild(s_select_text)
    th_select.appendChild(th_select_text)
    new_select.style.width = '100%'
    new_select.style.height = ''
    new_select.name='fields_names'
    new_select.classList.add('form-control')
    new_select.appendChild(f_select)
    new_select.appendChild(s_select)
    new_select.appendChild(th_select)
    td.appendChild(new_select)
    cur_table.appendChild(tr)
    //document.getElementById("approve_specification_table") = cur_table;
    console.log(cur_table.getElementsByTagName('tbody')); // генератор новой строчки
}