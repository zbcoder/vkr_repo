async function fill_chat(url){
    await fetch(url).then
}