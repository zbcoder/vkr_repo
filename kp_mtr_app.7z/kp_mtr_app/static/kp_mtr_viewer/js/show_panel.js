var current_url = document.location.protocol+'//'+document.location.host
console.log(current_url)

function show_panel(first_request, second_request){
    var full_url = current_url + first_request 
    console.log(current_url, first_request)
    mtr_characteristics = get_mtr_parameters(full_url)
    console.log(mtr_characteristics)
}

async function get_mtr_parameters(url){
    lock_screen()
    const request_params = {
        "method": "GET"
    }
    const response = await fetch(url, request_params)
    .then((response)=>{
        return response.json();
    })
    .then((data)=>{
        fill_labels(data)
        fill_table(data["mtr_characteristics"])
        show_bottom_modal();
        console.log(data['mtr_characteristics'], data['mtr_info']['mtr_group'])
    })
    .catch((err)=>{
        console.log(err)
    })
    .finally(()=>{
        document.querySelector('#spinner').classList.add('d-none');
    })
}


async function get_approvers(url){
    const response = await fetch(url, {"method": "GET"})
    .then((response)=>{
        return response.json()
    })
    .then((data)=>{
        console.log(data)
    })
    .catch((err)=>{
        console.log(err)
    })
}


function fill_labels(mtr_info){
    document.querySelector("#modal_header").innerHTML = 'Характеристика МТР: '+mtr_info['mtr_info']["name"]+' '+mtr_info['mtr_info']["characteristic"]
    document.querySelector('#mtr_code').innerHTML = mtr_info['mtr_info']["mtr_code"].toString().padStart(7, '0')
    document.querySelector('#current_mtr_code').value = mtr_info['mtr_info']["mtr_code"]
    document.querySelector('#current_rid').value = mtr_info['mtr_info']['mtr_rid']
    document.querySelector("#mtr_name").innerHTML = mtr_info['mtr_info']["name"]
    document.querySelector("#mtr_code_pattern").innerHTML = mtr_info['mtr_info']["mtr_group"]["mtr_code_pattern"]
    document.querySelector("#mtr_grp_name").innerHTML = mtr_info['mtr_info']["mtr_group"]["name"]
    document.querySelector("#supply_group").innerHTML = 
    mtr_info['mtr_info']["mtr_group"]["supply_group"]["div_no"] + ' ' +
    mtr_info['mtr_info']["mtr_group"]["supply_group"]["code"]
    document.querySelector("#supply_group_name").innerHTML = mtr_info['mtr_info']["mtr_group"]["supply_group"]["name"]
    document.querySelector("#um_name").innerHTML=mtr_info['mtr_info']["um_code"]["um_name"]
    document.querySelector('#price_value').innerHTML = price_choise(mtr_info["mtr_price"])
    document.querySelector('#str_reserve').innerHTML = mtr_info["mtr_ext"]["strategic_reserve_justification"] == null ? 'Стратегический запас не указан': mtr_info["mtr_ext"]["strategic_reserve_justification"]
    document.querySelector('#tr_rate').innerHTML = mtr_info["mtr_ext"]["transit_rate"] == null ? 'Транзитная норма не указана': mtr_info["mtr_ext"]["transit_rate"]
    document.querySelector('#tr_rate_justification').innerHTML = mtr_info["mtr_ext"]["transit_rate_justification"] == null ? 'Нет обоснования': mtr_info["mtr_ext"]["transit_rate_justification"]
    document.querySelector('#gid_value').innerHTML = mtr_info["mtr_ext"]["gid"] == null ? 'GID не указан': mtr_info["mtr_ext"]["gid"] 
    document.querySelector('#special_requirments').innerHTML = mtr_info["mtr_ext"]["special_requirments"] == null ? 'Специальные требования не указаны': mtr_info["mtr_ext"]["special_requirments"]
    document.querySelector('#okpd2').innerHTML = mtr_info["mtr_ext"]["okpd2_code"] == null ? 'Не указан': mtr_info["mtr_ext"]["okpd2_code"]
    document.querySelector('#ekps').innerHTML = mtr_info["mtr_ext"]["ekps_code"] == null? 'Не указан': mtr_info["mtr_ext"]["ekps_code"]
    document.querySelector('#fnn').innerHTML = mtr_info["mtr_ext"]["fnn_code"] == null? 'Не указан': mtr_info["mtr_ext"]["ekps_code"]
    document.querySelector('#who_responsible').innerHTML = mtr_info["mtr_ext"]["who_responsible"] == null? 'Не указан': mtr_info["mtr_ext"]["who_responsible"]
    // document.querySelector("#user_create").innerHTML = mtr_info["approvers_info"]["who_create"]
    // document.querySelector("#user_agr").innerHTML = mtr_info["approvers_info"]["who_agreement"]
    // document.querySelector("#user_approve").innerHTML =  mtr_info["approvers_info"]["who_approve"]
    console.log(mtr_info)
    //document.querySelector('#mtr_status').classList.add('disabled');
}

function fill_table(mtr_characteristics){
    for(i=0; i<mtr_characteristics.length; i++){
        var tr = document.createElement('tr')
        var value_td = document.createElement('td')
        var field_name_td = document.createElement('td')
        value_td.innerHTML = mtr_characteristics[i]["value"]=='None'?'':mtr_characteristics[i]["value"]
        field_name_td.innerHTML = mtr_characteristics[i]["supply_group_field"]["field"]["field_name"]
        tr.appendChild(field_name_td)
        tr.appendChild(value_td)
        document.getElementById("characteristic_table").appendChild(tr)
    }    
}


function checkText(message_input){
    if(message_input.value == ''){
        document.querySelector('.msg-button').classList.add('hidden')
    }
    else{
        document.querySelector('.msg-button').classList.remove('hidden')
    }
}


function price_choise(price_arr){
    let last_date_price=Date.now();
    console.log('now: ', Date(last_date_price), last_date_price)
    let prev_date = null;
    let last_price;
    for (counter=0; counter<price_arr.length; counter++){
        normal_date = new Date(price_arr[counter]["price_start_date"]).getTime()
        console.log(normal_date, last_date_price)
        if (last_date_price<normal_date){
            continue
        }
        else if (prev_date != null){
            if (prev_date > normal_date)
                continue
            else
                last_price = price_arr[counter]["price"]
                prev_date = normal_date
        }
        else
            last_price = price_arr[counter]["price"]
            prev_date = normal_date
        console.log(normal_date, last_date_price, last_price)
    }
    if (last_price == undefined)
        return 'Цена не указана'
    return last_price
}


function lock_screen(){
    document.querySelector('#spinner').classList.remove('d-none')
    document.querySelector('.overlay').classList.remove('hidden')
}
/*Изменение цвета при прокрутке*/

