function section_change_size(section_name){
    section = document.querySelector('#'+section_name)
    console.log(section.style.cssText)
    if (section.style.cssText == '--status: 1;'){
        section.style.cssText = '--status: 0;'
        section_show(section)
    }
    else
    {
        section_hide(section)
        section.style.cssText = '--status: 1;'
    }
}


function section_show(section){
    node_arr = section.children
    console.log(node_arr)
    for (node of node_arr){
        if (node.id == 'hide-btn')
            node.innerHTML = '&#8963;'
        node.classList.remove('hidden')
    }
}

function section_hide(section){
    node_arr = section.children
    for (node of node_arr){
        if (node.id =='hide-btn')
            node.innerHTML = '&#8964;'
        if (node.id != 'mtr-section-header' && node.id != 'hide-btn')
            node.classList.add('hidden')
    }
}

