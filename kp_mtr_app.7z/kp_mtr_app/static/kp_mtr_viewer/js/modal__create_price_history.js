// КОНСТАНТНАЯ ФУНКЦИЯ STR TO (OBJECT)DOCUMENTFRAGMENT
const createElFromStr = (str) => { return new Range().createContextualFragment(str)}

async function get_price_history(mtr_code){
    console.log('123123')
    const response = await fetch(url=`/api/mtr_price/${mtr_code}`)
    .then((response)=>{return response.json()})
    .then((data)=>{
        create_price_table(data["mtr_prices_history"])
    }) 
}

// 
function create_price_table(data){
    html_code = `
    <div class="d-none" id="price_table" style="height: 150px; overflow-y: scroll">
        <table class="table table-sm table-bordered">
            <thead>
                <th class="fw-bold">Дата н.д. цены</th>
                <th class="fw-bold">Цена, руб.</th>
                <th class="fw-bold">Обоснование цены</th>
            </thead>
            <tbody>
            ${data.map(i=>`
                <tr>
                    <td class="fs-5">${i['price_start_date']}</td>
                    <td class="fs-5">${i['price'].replace(/[^0-9,.?]$/, '')}</td>
                    <td class="fs-5">${i['price_justification']===null?'--': i['price_justification']}</td>
                </tr>
            `).join("")}
            </tbody>
        </table>
    </div>
    `
    document.querySelector('#diff_modal').prepend(createElFromStr(html_code));
}