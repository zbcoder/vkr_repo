function get_mtr_fields_values(url, selectObject){
    var supply_group_field = selectObject.value;
    var field_id = document.getElementById('id'+supply_group_field).value
    console.log(field_id)
    fetch(url)
    .then(function(response){
        return response.json()
    })
    .then(function (data){
        console.log(data)
        document.getElementById('sort_no').value = data["sort_no"]
        var option = document.getElementById('field_'+field_id)
        option.selected = 'selected'
        document.getElementById('type').value = data["type"]
        document.getElementById('register').value = data["register"]
        document.getElementById('template').value = data["template"]
        document.getElementById('current_supply_group_field_id').value = supply_group_field
        document.getElementById('upd_btn').style.display = 'block';
        document.getElementById('post_btn').style.display = 'none';
        document.getElementById('post_form').method = "PUT";
        document.getElementById('core').checked = Boolean(data["core"]);
        console.log(supply_group_field)
    })
    .catch(function(err){
        console.warn('Some went wrong ', err)
    })
}

//need api/supply_group_fields
function put_supply_group_fields()
{
    var supply_group_field = document.getElementById('current_supply_group_field_id').value
    console.log(document.getElementById('core').value)
    const element = document.getElementById('upd_btn');
    const requestOptions = {
        method: 'PUT',
        headers:{'Content-type':'application/json'},
        body: JSON.stringify({'supply_group_fields_id': supply_group_field,
                               'sort_no': document.getElementById('sort_no').value,
                               'field': document.getElementById('field_id').value,
                               'supply_group': document.getElementById('supply_group').value,
                               'template': document.getElementById('template').value,
                               'register': document.getElementById('register').value,
                               'core': Number(Boolean(document.getElementById('core').checked)),
                               'type': document.getElementById('type').value})
    }
    console.log(requestOptions.body)
    fetch('/api/supply_group_fields/'+supply_group_field, requestOptions)
    .then(response => response.json())
    .then(data => element.innerHTML = data.updateAt);
};