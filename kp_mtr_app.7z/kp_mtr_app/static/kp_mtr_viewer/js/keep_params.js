function keep_params(purpose_page){
    let url = new URL(document.location.href);
    console.log(url.searchParams.get('page'))
    url.searchParams.set('page', purpose_page);
    window.location.href = url
}