import csv
import json


def find(div_no, code):
    for supply_group_string in supply_group_json:
        if supply_group_string['div_no'] == div_no and code == supply_group_string['code']:
            return supply_group_string['supply_group_id']


def find_field(field_name):
    for fn in fields_string:
        if fn['field_name'] == field_name:
            return fn['field_id']


supply_group_json = []
fields_string = []
# Supply groups
with open(r'C:\Users\z79436\Desktop\mtr_data\группы_снабжения.csv', 'r', encoding='utf-8') as supply_group_csv:
    print(supply_group_csv)
    query_json = []
    csv_strings = csv.reader(supply_group_csv, delimiter=',')
    next(csv_strings)
    i = 1
    for csv_string in csv_strings:
        supply_group_json = {}
        supply_group_json.update({'supply_group_id': i,
                                  'name': csv_string[2],
                                  'div_no': csv_string[0],
                                  'code': csv_string[1]})
        query_json.append(supply_group_json)
        i += 1
    supply_group_json = query_json
    print(len(query_json), str(query_json).replace('\'', '"'), '\n\n\n\n\n\n')

# Mtr groups
with open(r'C:\Users\z79436\Desktop\mtr_data\группы_МТР.csv', 'r', encoding='utf-8') as mtr_group_csv:
    query_json = []
    csv_strings = csv.reader(mtr_group_csv, delimiter=',')
    next(csv_strings)
    for csv_string in csv_strings:
        pattern = 0
        try:
            pattern = int(csv_string[0].lstrip('0'))
        except:
            pattern = 0
        supply_group_id = find(csv_string[1], csv_string[2])
        cur_json = {}
        cur_json.update(
            {
                'name': csv_string[3],
                'mtr_code_pattern': pattern,
                'supply_group_id': supply_group_id
            }
        )
        query_json.append(cur_json)
    print(str(query_json).replace('\'', '"'), '\n\n\n\n\n\n\n')

# fn
with open(r'C:\Users\z79436\Desktop\mtr_data\наименование характеристик.csv', 'r', encoding='utf-8') as fields_names:
    query_json = []
    csv_strings = csv.reader(fields_names, delimiter=',')
    next(csv_strings)
    i = 1
    for csv_string in csv_strings:
        temp_json = {}
        temp_json.update({
            'field_id': i,
            'field_name': csv_string[0]
        })
        i += 1
        query_json.append(temp_json)
    fields_string = query_json
    print(str(query_json).replace('\'', '"'), '\n\n\n\n\n\n\n')

# # sgf
with open(r'C:\Users\z79436\Desktop\mtr_data\характеристики.csv', 'r', encoding='utf-8') as sgf_csv:
    query_json = []
    csv_strings = csv.reader(sgf_csv, delimiter=',')
    next(csv_strings)
    for csv_string in csv_strings:
        supply_group = find(csv_string[0], csv_string[1])
        temp_json = {}
        temp_json.update({
            'sort_no': csv_string[2].lstrip('Поле_0'),
            'field_id': find_field(csv_string[3]),
            'supply_group_id': supply_group,
            'template': csv_string[4],
            'register': csv_string[5],
            'core': None,
            'type': None
        })
        query_json.append(temp_json)
    print(str(query_json).replace('\'', '"').replace('None', 'null').replace('"null"', 'null'), '\n\n\n\n\n\n\n')
    # print(query_json, '\n\n\n\n\n\n\n')

with open(r'C:\Users\z79436\Desktop\mtr_data\Единица измерения.csv', 'r', encoding='utf-8') as ei:
    query_json = []
    csv_strings = csv.reader(ei, delimiter=',')
    next(csv_strings)
    next(csv_strings)
    for csv_string in csv_strings:
        temp_json = {}
        temp_json.update({
            'um_code': csv_string[0].lstrip('0'),
            'um_name': csv_string[1]
        })
        query_json.append(temp_json)
    print(str(query_json).replace('\'', '"'), '\n\n\n\n\n\n')
