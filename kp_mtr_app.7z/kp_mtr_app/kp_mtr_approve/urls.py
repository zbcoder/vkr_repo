from django.contrib import admin
from django.urls import path

from django.contrib import admin
from django.urls import path
from django.conf.urls import url, include
from .views import *

urlpatterns = [
    # path(r'add/'),
    # path(r'add/mtr'),
    # path(r'add/mtr/group'),
    path(r'do_approve/<int:mtr_rid>/', do_approve, name='do_approve'),
    path(r'add/', create_approves, name='create_request_for_mtr'),
    path(r'temp', temp),
    path(r'list', approves_by_div, name='approves_list'),
    path(r'history', approves_history, name='approves_history'),
    path(r'history/ended', approves_history_ended, name='approves_history_ended'),
    path(r'mtr-change/<int:mtr_rid>/', mtr_change, name='mtr-change'),
    path(r'proccess', approve_proccess, name='approve_proccess'),
    path(r'history/myself', approves_history_myself, name='myself_history'),
]
