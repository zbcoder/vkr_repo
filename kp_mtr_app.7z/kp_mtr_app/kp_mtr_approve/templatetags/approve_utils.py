from django import template
from datetime import datetime
import time

register = template.Library()


@register.filter()
def add_zeroes(value):
    return str(value).zfill(3)

@register.filter()
def add_zeroes_to_mtr(value):
    return str(value).zfill(7)

@register.filter()
def add_n_zeroes(value, n):
    return str(value).zfill(n)


@register.filter()
def find_need(value, id):
    for role in value:
        if role.id == id:
            return True
        else:
            continue
    else:
        return None


@register.filter()
def NoneReplace(value):
    if value == None or value == 'None':
        return ''
    else:
        return value 


@register.filter()
def cut(value):
    return value[:42]+'...'


@register.filter(name='zip')
def zip_lists(a, b):
    return zip(a, b)


@register.filter(name='del')
def remove_last_symbol(money):
    if money is not None:
        return money[:-1]
    else: return None


@register.filter(name='get_last_price')
def get_last_price(price_arr):
    print(len(price_arr))
    if len(price_arr) is not 0:
        last_date = 0.
        price = 0
        for price in price_arr:
            date_list = list(datetime.strptime(price.get("price_start_date"),'%Y-%m-%dT%H:%M:%SZ').date().timetuple())
            try:
                price_time = time.mktime(datetime(date_list[0], date_list[1], date_list[2]).timetuple())
            except:
                price_time = 0.
            if datetime.timestamp(datetime.now()) < price_time:
                continue
            else:
                if last_date:
                    if last_date > price.get("price_start_date"):
                        continue
                    else:
                        last_date = price.get("price_start_date")
                        last_price = price.get("price")
                else: 
                    last_date = price.get("price_start_date")
                    last_price = price.get("price")
        return last_price
    else: return None
            