from dataclasses import field
from turtle import clear
import requests
import json
import uuid
from django.core.serializers.json import DjangoJSONEncoder
from django.db import connections
from django.contrib import messages
from mtr_api.models import *
from django.db.models import Q

chat_api_create_uri = 'chat_api/chat/'


def create_chat(mtr_rid, user=8, host='127.0.0.1', port='8080'):
    print('________________________________________________\n', mtr_rid, host, port)
    create_uri = 'http://' + host + ':' + port + '/' + chat_api_create_uri
    chatroom_uuid = uuid.uuid4()
    chat_content = {
        'chatroom_uuid': str(chatroom_uuid),
        'chatroom_name': f'chat_by_rid_{mtr_rid}',
        'chatroom_created_by': user
    }
    mtr_response = requests.get(f'http://127.0.0.1:8000/api/mtr/{mtr_rid}/')
    new_context = mtr_response.json()
    if mtr_response.json()['chatroom_uid'] is None:
        try:
            print(create_uri)
            chat_response = requests.post(url=create_uri, json=chat_content)
            new_context['chatroom_uid'] = str(chatroom_uuid)
            print(new_context)
            put_response = requests.put(url=f'http://127.0.0.1:8000/api/mtr/{mtr_rid}/', json=new_context)
            print(put_response.text)
            print(chat_response.text)
            alert_class = 'alert alert-success'
            context = 'Переписка по RID успешно создана'
        except Exception as e:
            print(e)
            alert_class = 'alert alert-danger'
            context = 'Переписка по RID не была создана. Она будет создана во время написания первого сообщения.'
        finally:
            return ({'alert-class': alert_class, 'context': context})
    else:
        return ({'alert-class': 'alert alert-warning', 'context': 'Переписка по данному RID уже существует'})


# Ищет RIDы по параметрам
def search_function(request):
    # Определение и объявление GET параметров
    code_qs = str(request.GET.get('code_filter')) if request.GET.get('code_filter') or request.GET.get('code_filter')== '' else None
    name_qs = str(request.GET.get('name_filter')) if request.GET.get('name_filter') or request.GET.get('name_filter')== '' else None
    um_code = request.GET.get('um_code')
    clear_list = []
    for i in request.GET.getlist('additional_attr'):
        if i != '':
            clear_list.append(str(i).upper())
    clear_list = str(clear_list).replace('[', '{').replace(']', '}').replace('\'', '"')
    cursor = connections['mtr'].cursor()
    code_qs = str(request.GET.get('code_filter')) if request.GET.get('code_filter') or request.GET.get('code_filter')== '' else None
    # Подготовка параметров к запросу
    if name_qs is not None:
        name_qs = name_qs.upper()
    if code_qs is not None:
        code_qs = code_qs.lstrip('0')
    if um_code is not None:
        um_code = um_code.lstrip('0')
    # QuerySet
    if code_qs is None and name_qs is None and len(request.GET.getlist('additional_attr'))==0:
        return None
    else:
        print(code_qs, um_code, name_qs, clear_list)
        cursor.execute(f'SELECT * FROM mtr.rid_search_func(\'{str(code_qs)}\', \'{str(um_code)}\', \'{str(name_qs)}\', \'{clear_list}\')')
        res = [elem[0] for elem in cursor.fetchall()]
        print(res)
        return res


# ПОВЕРХНОСТНЫЙ ПОИСК МТР
def search_mtr(request):
    code_qs = str(request.GET.get('code_filter')) if request.GET.get('code_filter') or request.GET.get('code_filter')== '' else ''
    name_qs = str(request.GET.get('name_filter')) if request.GET.get('name_filter') or request.GET.get('name_filter')== '' else ''
    supply_group = request.GET.get('supply_group') if request.GET.get('supply_group') else None
    um_code = request.GET.get('um_code')
    fields_dict = []
    values_dict = []
    print('supply: ', supply_group)
    if supply_group is not None:
        fields = request.GET.getlist('supply_group_field')
        values = request.GET.getlist('field_value')
        for i in range(len(fields)):
            # values[i] = values[i].lstrip(' ')
            # print(len(values[i]))
            if len(values[i]) !=0:
                fields_dict.append(fields[i])
                values_dict.append(values[i])
                # fields_dict.append({Q(supply_group_field_id = fields[i])&Q(value=values[i])})
            else: continue
        print(fields_dict)


    if name_qs is not None:
        name_q = Q(name__icontains=name_qs.upper())|Q(characteristic__icontains=name_qs.upper())
    name_an_q = (Q(name__startswith='')&Q(characteristic__startswith=''))
    
    if code_qs is not None:
        code_q = Q(mtr_code__startswith=code_qs.lstrip('0'))
    code_an_q = Q(mtr_code__startswith='')

    if um_code is not None:
        um_q = Q(um_code__um_code__startswith = um_code.lstrip('0'))
    um_an_q = Q(um_code__um_code__startswith = '')

    if supply_group is not None:
        if len(fields_dict)!=0:
            additional_qs = MtrFieldsValues.objects.values('mtr_rid').filter(Q(supply_group_field__in = fields_dict)&Q(value__in=values_dict))
            # ЕСЛИ ЕСТЬ ДОПОЛНИТЕЛЬНЫЕ ПОЛЯ ДЛЯ ПОИСКА
            return Mtr.objects.filter(
                    name_q if name_qs is not None else name_an_q, 
                    code_q if code_qs is not None else code_an_q, 
                    um_q if um_code is not None else um_an_q, 
                    Q(mtr_group__supply_group__supply_group_id=supply_group), current=True,
                    mtr_rid__in = additional_qs)
        # ЕСЛИ ГРУППА СНАБЖЕНИЯ ВЫБРАНА, НО ДОПОЛНИТЕЛЬНЫЕ ПОЛЯ НЕ ВВЕДЕНЫ
        return Mtr.objects.filter(
                    name_q if name_qs is not None else name_an_q, 
                    code_q if code_qs is not None else code_an_q, 
                    um_q if um_code is not None else um_an_q, 
                    Q(mtr_group__supply_group__supply_group_id=supply_group), current=True)
    # САМЫЙ ОБЫЧНЫЙ ПОИСК
    return Mtr.objects.filter(
                    name_q if name_qs is not None else name_an_q, 
                    code_q if code_qs is not None else code_an_q, 
                    um_q if um_code is not None else um_an_q, current=True)


def is_none(num):
    return num is not None

if __name__ == '__main__':
    result = create_chat(2)
    print(result)