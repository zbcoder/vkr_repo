from ast import Num
from calendar import c
from distutils.command.clean import clean
from operator import ne
from django.contrib import messages
from re import template
from telnetlib import STATUS
from xmlrpc.client import Boolean
from django.db.models import Max, Q
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect, request, JsonResponse, HttpResponseNotAllowed, HttpResponseNotFound
from django.views import generic
from django.core import serializers as ser
from mtr_api.models import *
from .serializers import *
from datetime import datetime
from django.db import connections
from .source.utilities import *
from django.views.generic import TemplateView
from .models import Users
import json
import requests
from .utils import *
from django.contrib.auth.decorators import permission_required, login_required
from datetime import datetime
from kp_mtr_approve.approve_logic.approve_logic import *
from django.views.generic import UpdateView
from django.core.paginator import Paginator
from django.urls import reverse


# Create your views here. 1 - who create, 2 - approver
@login_required
def do_approve(request, mtr_rid):
    # Проверка на возможность редактирования записи
    cursor = connections['mtr'].cursor()
    cursor.execute(f'SELECT * FROM mtr.check_for_edtability({mtr_rid});')
    is_editability = cursor.fetchone()[0]
    print(is_editability)
    qs = MtrApproves.objects.filter(mtr_rid=mtr_rid).exclude(result__isnull=False).order_by('mtr_approve_id')[:1]
    serializer = MtrApprovesSerializer(qs, many=True)
    get_fields_values = requests.get('http://'+request.get_host()+f'/api/mtr_info_by_rid/{mtr_rid}')
    fields_json = get_fields_values.json()
    all_divisions = json.loads(ser.serialize('json', MtrApproves.objects.filter(mtr_rid=mtr_rid).order_by('num').distinct('num')))
    current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
    current_approves = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)
    if request.method == 'GET':
        
        return render(request=request, template_name='do_approve.html', context={'approves': qs,
                                                                                'values_info': fields_json,
                                                                                'current_user_info': current_user_info,
                                                                                'current_approves': len(current_approves),
                                                                                'all_divisions': all_divisions,
                                                                                'is_editability': is_editability})
    else:
        print(request.POST, request.META.get('HTTP_REFERER'))
        result = request.POST.get('approve_bool_val')
        mtr_approve_id = request.POST.get('approve_id')
        print('mtr_approve: ', mtr_approve_id, ' result: ', result)
        current_approve = MtrApproves.objects.get(pk=mtr_approve_id)
        editing_mtr_rid = current_approve.mtr_rid.pk
        mtrcode = request.POST.get('form_mtr_code')
        errors = []
        print(not result)
        try:
            if request.POST.get('form_mtr_code') == '':
                errors.append('Вы допустили ошибку в поле ввода кода МТР')
            if int(request.POST.get('form_mtr_code'))<1 or int(request.POST.get('form_mtr_code'))>9999 and current_approve.mtr_rid.pk == 0:
                errors.append('Неккоректное значение кода МТР')
            elif not result:
                errors.append('Пожалуйста, выберите результат согласования!')
            else:

                if current_approve.mtr_rid.mtr_code == 0:
                    changed_mtr = Mtr.objects.get(pk=editing_mtr_rid)
                    changed_mtr.mtr_code = int(str(current_approve.mtr_rid.mtr_group.mtr_code_pattern).zfill(3) + mtrcode)
                    changed_mtr.save()
                current_approve.ts_approve = datetime.now()
                current_approve.user_approve = request.user.username
                current_approve.result = result
                current_approve.save()
                if result == 'False':
                    if(current_approve.num==1):
                        last_round_approves = MtrApproves.objects.filter(mtr_rid = current_approve.mtr_rid.mtr_rid, approve_round=current_approve.approve_round)
                        for lr_approve in last_round_approves:
                            lr_approve.result = False
                            lr_approve.user_approve = request.user.username
                            lr_approve.save()
                    print(current_approve.approve_round)
                    if current_approve.num != 1 and current_approve.approve_round < 3:
                        new_approveround = int(current_approve.approve_round) + 1 
                        approve_qs = json.loads(ser.serialize('json', MtrApproves.objects.
                        filter(mtr_rid=current_approve.mtr_rid.pk, approve_round = current_approve.approve_round).
                        annotate(Max("approve_round")).order_by("num")))
                        print(approve_qs)
                        for approve in approve_qs:
                            print(new_approveround)
                            print(current_approve.mtr_rid.pk, '\n',
                            datetime.now(), '\n',
                            request.user.id, '\n',
                            approve['fields'].get('div_no'), '\n',
                            approve['fields'].get('num'),'\n',
                            new_approveround)
                            MtrApproves(
                                mtr_rid = Mtr.objects.get(pk = editing_mtr_rid),
                                role_id = 2, #placeholder
                                ts_create = datetime.now(),
                                source_create = ApproveSorces.objects.get(pk=1), # placeholder
                                user_create = request.user.username,
                                div_no = approve['fields'].get('div_no'),
                                num = approve['fields'].get('num'),
                                approve_round = new_approveround
                            ).save()
                    elif current_approve.approve_round == 3:
                        errors.append("Согласование закончено с отрицательным результатом. Подайте повторную заявку на код МТР")
                elif result == 'True' and current_approve.num==2:
                    # update mtr state 
                    cursor = connections['mtr'].cursor()
                    if current_approve.mtr_rid.mtr_code != int(mtrcode):
                        cursor.execute('SELECT * FROM mtr.change_mtr_status(%d, %d)' % (int(editing_mtr_rid), 
                        int(str(current_approve.mtr_rid.mtr_group.mtr_code_pattern) + mtrcode)))
                    else:
                        print('SELECT * FROM mtr.change_mtr_status(%d, %d)' % (int(editing_mtr_rid), int(mtrcode)))
                        cursor.execute('SELECT * FROM mtr.change_mtr_status(%d, %d)' % (int(editing_mtr_rid), int(mtrcode)))
                return redirect('approves_list')
        except Exception as e:
            errors.append(e)
        if errors:
            return render(request=request, template_name='do_approve.html', context={'approves': serializer.data,
                                                                                 'values_info': fields_json,
                                                                                 'current_user_info': current_user_info,
                                                                                 'current_approves': len(current_approves),
                                                                                 'all_divisions': all_divisions,
                                                                                 'errors': errors})


@login_required(login_url='signin')
def create_approves(request):
    print(r'Wow, its: ', request.method)
    qs_um_json = [i.as_dict() for i in UnitMeasure.objects.all()]
    qs_mtr_json = [i.as_dict() for i in Mtr.objects.all()]
    qs_fn_json = [i.as_dict() for i in FieldsNames.objects.all()]
    divisions_json = [i for i in SupplyGroups.objects.values('div_no').order_by('div_no').distinct()]
    queryset = Mtr.objects.all().values_list()
    current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
    current_approves = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)
    if request.method == 'GET':
        return render(request, 'create_approve.html', context={'mtr_data': qs_mtr_json,
                                                               'um_data': qs_um_json,
                                                               'fn_data': qs_fn_json,
                                                               'mtr_groups': MtrGroups.objects.all(),
                                                               'divisions': divisions_json,
                                                               'current_approves': len(current_approves)})
    elif request.method == 'POST':  # POST
        # Django model realisation
        # Need add create division to auth table for correct work
        data = request.POST
        print(data.get('conditional_mtrcode'))
        supply_group_fields = data.getlist('supply_group_field_id')
        mtr_rid_fields = data.getlist('field_id[]')
        mtr_rid_values = data.getlist('field_value[]')
        first_approve_result = is_group(request.user.groups.all(), 2) # role 2 is mtr_approves
        next_mtr = Mtr.objects.aggregate(Max('mtr_rid')).get('mtr_rid__max') + 1
        current_user_info = ser.serialize('json', Users.objects.filter(account_name=request.user))
        user_json_obj = json.loads(current_user_info)
        ##################################### VALIDATE (MTR_GROUP, DIV_NO, MTR_NAME)##################################################
        if data.get('div')=='None' or data.get('mtr_name')=='' or data.get('mtr_group')=='':
            cleaned_data = {
                'div':data.get('div'), 
                'mtr_name':data.get('mtr_name'),
                'mtr_group': data.get('mtr_group'),
                'mtr_code': False if data.get('mtr_code')==0 else data.get('mtr_code'),
                'um_code': data.get('um_code'),
                'special_requirments': data.get('special_requirments')
            }
            messages.error(request, 'Ошибка валидации, проверьте данные формы!')
            return render(request, 'create_approve.html', context={
                'mtr_data': qs_mtr_json,
                'um_data': qs_um_json,
                'fn_data': qs_fn_json,
                'mtr_groups': MtrGroups.objects.all(),
                'divisions': divisions_json,
                'current_approves': len(current_approves),
            #    'errors': ['Ошибка валидации, проверьте данные формы!'],
                'cleaned_data': cleaned_data
                })
        else:
            print('i tut', data)
            try:
                new_mtr = Mtr(
                    mtr_rid=next_mtr,
                    mtr_code=data['mtr_code'],
                    name=data['mtr_name'],
                    um_code=UnitMeasure.objects.get(pk=int(data['um_code'])),
                    mtr_group=MtrGroups.objects.get(pk=int(data['mtr_group'])),
                    conditional=True if data.get('conditional_mtrcode')=='on' else False).save()
                # Первое согласование от того, отдела, участник которого создал
                if is_group(request.user.groups.all(), 2):
                    first_approve = MtrApproves(
                        mtr_rid=Mtr.objects.get(pk=next_mtr),
                        role_id = 2,  # it's placeholder role 1 - create, role 2 - approve
                        ts_create=str(datetime.now()),
                        ts_approve = str(datetime.now()),
                        source_create=ApproveSorces.objects.get(pk=1),  # placeholder MU20P
                        user_create = request.user.username,
                        user_approve = request.user.username,
                        result=first_approve_result,
                        div_no = user_json_obj[0].get('fields').get('division'),
                        num=1,
                        approve_round=1).save()
                else:
                    first_approve = MtrApproves(
                        mtr_rid=Mtr.objects.get(pk=next_mtr),
                        role_id = 2,  # it's placeholder role 1 - create, role 2 - approve
                        ts_create=str(datetime.now()),
                        source_create=ApproveSorces.objects.get(pk=1),  # placeholder
                        user_create = request.user.username,
                        result=first_approve_result,
                        div_no = user_json_obj[0].get('fields').get('division'),
                        num=1,
                        approve_round=1).save()
                second_approve = MtrApproves(
                    mtr_rid=Mtr.objects.get(pk=next_mtr),
                    role_id=2,  # role 2 - is approve
                    ts_create=str(datetime.now()),
                    source_create=ApproveSorces.objects.get(pk=1),  # placeholder
                    user_create = request.user.username,
                    div_no = data['div'].strip('0'),
                    num=2,
                    approve_round=1).save()
                characteristic_field = ''
                for i in range(len(mtr_rid_values)):
                    MtrFieldsValues(value_id=MtrFieldsValues.objects.aggregate(Max('value_id')).get('value_id__max') + 1,
                                    supply_group_field=SupplyGroupFields.objects.get(pk=int(supply_group_fields[i])),
                                    value=mtr_rid_values[i],
                                    ts_add=str(datetime.now()),
                                    mtr_rid=Mtr.objects.get(pk=next_mtr),
                                    user_add=request.user.username).save()
                cursor = connections['mtr'].cursor()
                cursor.execute(f'SELECT * FROM mtr.get_mtr_full_characteristic({next_mtr})')
                tmp_mtr = Mtr.objects.get(pk=next_mtr)
                tmp_mtr.characteristic = cursor.fetchone()[0]
                tmp_mtr.save()
                print(request.POST.get("special_requirments"))
                if request.POST.get("special_requirments"):
                    mtr_ext = MtrExt()
                    mtr_ext.mtr_rid = Mtr.objects.get(pk=next_mtr)
                    mtr_ext.special_requirments = request.POST.get("special_requirments")
                    mtr_ext.save()
                result = 'Save complete'
                alert_result = create_chat(next_mtr)
                print(alert_result)
                messages.success(request, 'Заявка на код МТР успешно добавлена')
            except Exception as e:
                result = 'Save Error'
                print(e)
            return redirect(request.path, context={'mtr_data': qs_mtr_json,
                                                'um_data': qs_um_json,
                                                'fn_data': qs_fn_json,
                                                'status': result})


@login_required
def temp(request):
    print('\n\n\n\n\n\n', request.method, ' ', request.GET, ':\n\n')
    mtr_list = Mtr.objects.select_related('um_code').only('mtr_code', 'mtr_code', 'um_code__um_name')
    json_arr = []
    cursor = connections['mtr'].cursor()
    cursor.execute('SELECT DISTINCT(sg.div_no) from mtr.mtr_groups mg '
                   'inner join mtr.supply_groups sg on sg.supply_group_id= mg.supply_group_id')
    first_query_result = cursor.fetchall()
    for div_no in first_query_result:
        test_json = {}
        div_number = str(div_no[0])
        test_json.update({'div_no': div_number, 'items': []})
        cursor.execute(f'SELECT DISTINCT(sg.code) from mtr.mtr_groups mg inner join mtr.supply_groups sg '
                       f'on sg.supply_group_id= mg.supply_group_id where sg.div_no=\'{div_number}\'')
        codes = cursor.fetchall()
        i = 0
        for code in codes:
            test_json['items'].append({'code': code[0], f'values': []})
            cursor.execute(f'SELECT DISTINCT(mg.mtr_code_pattern), mg.mtr_group_id '
                           f'from mtr.mtr_groups mg inner join mtr.supply_groups sg '
                           f'on sg.supply_group_id= mg.supply_group_id where code=\'{code[0]}\'')
            mtr_patterns = cursor.fetchall()
            for mtr_pattern in mtr_patterns:
                cursor.execute(f'SELECT mt.mtr_code from mtr.mtr mt where mt.mtr_group_id = {mtr_pattern[1]}')
                mtr_codes = cursor.fetchall()
                mtr_pattern_json = {}
                mtr_pattern_json.update({'mtr_pattern': int(mtr_pattern[0]), 'mtr_code': []})
                print(mtr_codes)
                for mtr_code in mtr_codes:
                    mtr_pattern_json['mtr_code'].append(mtr_code[0])
                test_json['items'][i].get('values').append(mtr_pattern_json)
            i += 1
        json_arr.append(test_json)

    print(json_arr)
    cursor.close()
    if request.GET == {}:
        print('its not default way')
        return render(request, 'search_mtr_tree.html', context={'values': json_arr})
    else:
        print('its not default way', request.GET)
        current_mtr = request.GET['current_mtr']
        con = connections['mtr'].cursor()
        con.execute(f'SELECT mtr_rid FROM mtr.mtr where mtr_code={int(current_mtr)}')
        mtr_rid = con.fetchone()
        con.execute(f'SELECT * FROM mtr.mtr_approves'
                    f' where user_approve is not null and ts_approve is not null'
                    f' and mtr.mtr_approves.mtr_rid={mtr_rid[0]}')
        approves_by_mtr_id = con.fetchall()
        print(approves_by_mtr_id, 'mtr_rid: ', mtr_rid[0])
        print('mtr_rid placeholder ', con.fetchall())
        con.execute(f'SELECT * FROM mtr.fields_for_rid({mtr_rid[0]})')
        values_list = con.fetchall()
        print(values_list)
        return render(request, 'search_mtr_tree.html',
                      context={'values': json_arr, 'fields_values': values_list,
                               'mtr_code': current_mtr, 'mtr_rid': mtr_rid[0],
                               'approves_history': approves_by_mtr_id})



@login_required
def approves_by_div(request):
    current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
    # current_approves = json.loads(ser.serialize('json', MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False), fields='mtr_rid, mtr_rid__name'), depth=2)
    current_approves = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)
    serializer = MtrApprovesSerializer(current_approves, many=True)
    for elem in serializer.data:
        datetime_str = elem['ts_create'].split('T')[0]+' '+elem['ts_create'].split('T')[1].rstrip('Z')
        elem['ts_create'] = datetime.strptime(datetime_str,'%Y-%m-%d %H:%M:%S')
    return render(request, template_name='approve_list.html', context={'current_approves': len(current_approves), 'approves_list': current_approves, 'res': serializer.data})


# История согласований, которые отправил пользователь, (или согласовывал - уточнить)
@login_required
def approves_history(request):
    if request.method=="GET":
        # Стандартный контекст всех tempaltes
        current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
        current_approves = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)
        
        # Сортировка по харакатеристикам. В res вернется отфильтрованный QS
        # откуда необходимо будет взять list rid'ов
        
        res = search_mtr(request) # Функция для поиска null если не заданы поля для поиска
        res_pk = [mtr.pk for mtr in res] if res is not None else None

        if request.GET.get('status') == None:
            return redirect(reverse('approves_history')+'?status=current')
        elif request.GET.get('status') == '' or request.GET.get('status') == 'current':
            print('current')
            if res is not None:
                model = MtrApproves.objects.select_related('mtr_rid').filter(mtr_rid__in = res_pk, div_no=current_user_info[0]['fields']['division'], 
                        user_create=current_user_info[0]['fields']['account_name']).distinct()
            else:
                model = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division'], 
                        user_create=current_user_info[0]['fields']['account_name']).distinct()
            serializer = MtrApprovesSerializer(model, many=True)
        
            # Добавление к МТР истории о доступности его согласования
            for counter, elem in enumerate(serializer.data,0):
                elem.update({'is_available': True})
                datetime_str = elem['ts_create'].split('T')[0]+' '+elem['ts_create'].split('T')[1].rstrip('Z')
                elem['ts_create'] = datetime.strptime(datetime_str,'%Y-%m-%d %H:%M:%S')
            
            p = Paginator(serializer.data, 20)
        elif request.GET.get('status') == 'ended':
            print('ended')
            div = current_user_info[0]['fields']['division']
            cursor = connections['mtr'].cursor()
            cursor.execute(f'SELECT * FROM mtr.give_complete_approves(\'{div}\')')
            styles_table = cursor.fetchall()
            finally_rids = []
            if res is not None:
                for index in styles_table:
                    if index[1] in res_pk:
                        finally_rids.append(index)
                p = Paginator(finally_rids, 30)
            else:    
                p = Paginator(styles_table, 30)
        elif request.GET.get('status') == 'myself':
            print('myself')
            # Текущий пользователь + завершенные согласования
            cursor = connections['mtr'].cursor()
            cursor.execute(f'SELECT * FROM mtr.give_myself_approves(\'{request.user}\')')
            styles_table = cursor.fetchall()
            finally_rids = []
            if res is not None:
                for index in styles_table:
                    if index[1] in res_pk:
                        finally_rids.append(index)
                p = Paginator(finally_rids, 30)
            else:
                p = Paginator(styles_table, 30)
        else:
            return HttpResponseNotAllowed('Bad args')
        # Пагинаторс
        page = request.GET.get('page')
        page_obj = p.get_page(page)

        return render(request, template_name='approve_history.html', 
        context={
                'current_approves': len(current_approves), 
                'approves_list': json.loads(ser.serialize('json', current_approves)),
                'res': page_obj,
                'current_user_info': current_user_info,
                'order_style': 1 if not request.GET.get('order-style') else int(request.GET.get('order-style'))
            })
    else:
        return HttpResponseNotAllowed("Method not allowed")


# Изменение характеристик кода МТР
def mtr_change(request, mtr_rid):
    is_available = json.loads(ser.serialize('json', MtrApproves.objects.filter(mtr_rid=mtr_rid).exclude(result__isnull=False).order_by('mtr_approve_id')[:1]))
    qs = MtrFieldsValues.objects.select_related('supply_group_field').\
        select_related('supply_group_field__field').filter(mtr_rid=mtr_rid)
    serializer = MtrFieldsValuesSerializer(qs, many=True)
    return render(request=request, template_name='mtr_edit.html', context={'fields_values': serializer.data,
                                                                            'is_available': is_available})

# согласование view
def approve_proccess(request):
    print(request.GET)
    print(request.POST, request.META.get('HTTP_REFERER'))
    result = request.POST.get('approve_bool_val')
    mtr_approve_id = request.POST.get('approve_id')
    print('mtr_approve: ', mtr_approve_id, ' result: ', result)
    current_approve = MtrApproves.objects.get(pk=mtr_approve_id)
    if result:
        print(1)
    else:
        errors = 'Выберите результат согласования!'
        # return HttpResponse(content='Ошибка', status=300)
        # return redirect(request.META.get('HTTP_REFERER'), context={'errors': 'Выберите действие!!!'})
    return HttpResponse()


@login_required
def approves_history_ended(request):
    # Текущий пользователь + завершенные согласования
    current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
    current_approves = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)
    # Результат запроса
    div = current_user_info[0]['fields']['division']
    print(div)
    cursor = connections['mtr'].cursor()
    cursor.execute(f'SELECT * FROM mtr.give_complete_approves(\'{div}\')')
    styles_table = cursor.fetchall()
    res = search_function(request)
    finally_rids = []
    if res is not None:
        for index in styles_table:
            if index[1] in res:
                finally_rids.append(index)
        p = Paginator(finally_rids, 30)
    else:    
        p = Paginator(styles_table, 30)
    page = request.GET.get('page')
    page_obj = p.get_page(page)
    result = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=True)
    return render(request, 'approve_history.html',
    context={
        'current_approves': len(current_approves),
        'ended_res': page_obj,
        'current_user_info': current_user_info,
        'approves_list': json.loads(ser.serialize('json', current_approves))
    })


@login_required
def approves_history_myself(request):
    # Текущий пользователь + завершенные согласования
    current_user_info = json.loads(ser.serialize('json', Users.objects.filter(account_name=request.user)))
    current_approves = MtrApproves.objects.select_related('mtr_rid').filter(div_no=current_user_info[0]['fields']['division']).exclude(result__isnull=False)
    # Результат запроса
    
    cursor = connections['mtr'].cursor()
    cursor.execute(f'SELECT * FROM mtr.give_myself_approves(\'{request.user}\')')
    res = search_function(request)
    styles_table = cursor.fetchall()
    print(type(styles_table))
    finally_rids = []
    if res is not None:
        for index in styles_table:
            print(index, res)
            if index[1] in res:
                finally_rids.append(index)
        p = Paginator(finally_rids, 30)
    else:
        p = Paginator(styles_table, 30)
    page = request.GET.get('page')
    page_obj = p.get_page(page)
    return render(request, 'approve_history.html',
    context={
        'current_approves': len(current_approves),
        'myself_res': page_obj,
        'current_user_info': current_user_info,
        'approves_list': json.loads(ser.serialize('json', current_approves))
    })