from django.contrib import admin
from django.contrib.admin import forms
from django import forms as fm
from mtr_api.models import *
# Register your models here.

# Кастомные формы для полей выбора
class CustomModelChoiseField(fm.ModelChoiceField):
    def label_from_instance(self, obj):
        return "%s %s" % (obj.field_name, obj.field_id)


class MGCustomChoiseField(fm.ModelChoiceField):
    def label_from_instance(self, obj):
        return "%s %s %s" % (obj.div_no, obj.code, obj.name)


# Кастомные формы для моделей админки
class SGFAdminForm(fm.ModelForm):
    core = fm.BooleanField()
    field = CustomModelChoiseField(queryset = FieldsNames.objects.all())


class MGAdminForm(fm.ModelForm):
    supply_group = MGCustomChoiseField(queryset = SupplyGroups.objects.all())

# Класс позволяющий создать вложенность формы на ../supplygroups/<int:>

class SGFAdmin(admin.TabularInline):
    model = SupplyGroupFields
    list_display = ['sort_no', 'field', 'core']
    form = SGFAdminForm
    
    def get_form(self, request, obj=None, **kwargs):
        form = super(SGFAdmin, self).get_form(request, obj, **kwargs)
        form.fields['field'].label_from_instance = lambda inst: '%s %s'.format(inst.field_id, inst.field_name)
        return form 

# Классы для отображения форм
class SGAdmin(admin.ModelAdmin):
    list_display = ['name', 'div_no', 'code']
    fields = ['name', 'div_no', 'code']
    inlines = [SGFAdmin,]

class MGAdmin(admin.ModelAdmin):
    form = MGAdminForm
    list_display = ['name', 'mtr_code_pattern', 'supply_group']
    fields = ['name', 'mtr_code_pattern', 'supply_group']


admin.site.register(SupplyGroups, SGAdmin)
admin.site.register(MtrGroups, MGAdmin)