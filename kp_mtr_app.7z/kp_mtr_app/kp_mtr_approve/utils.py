# Проверка на наличие группы у пользователя
def is_group(user, _role):
    for role in user:
        print(role.id)
        if _role == role.id:
            return True
    return None
