import datetime
from django.db.models import Max

from mtr_api.models import *


def qdict_to_dict(qdict):
    return {k: v[0] if len(v) == 1 else v for k, v in qdict.lists()}


def mtr_dict(qdict):
    return {
        'mtr_rid': Mtr.objects.aggregate(Max('mtr_rid')).get('mtr_rid__max')+1,
        'mtr_code': qdict['mtr_code'],
        'name': qdict['mtr_name'],
        'um_code': int(qdict['um_code']),
        'mtr_group': int(qdict['mtr_group'])
    }


def approve_dict(qdict):
    return {
        'mtr_rid': Mtr.objects.aggregate(Max('mtr_rid')).get('mtr_rid__max'),
        'role_id': 1,  # it's placeholder
        'ts_create': str(datetime.datetime.now()),
        'source_create': 1,  # placeholder
        'user_create': qdict['user_create']
    }


def mtr_value(value, field_id):
    return {
        'supply_group_field': field_id,
        'value': value,
        'ts_add': str(datetime.datetime.now()),
        'mtr_rid': Mtr.objects.aggregate(Max('mtr_rid')).get('mtr_rid__max'),
        'user_add': 'z_79436'  # placeholder
    }