from rest_framework import serializers
from mtr_api.models import *


class MtrApprovesSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrApproves
        fields = '__all__'
        depth = 2


class MtrSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mtr
        fields = ["mtr_code", "name", "um_code", "mtr_rid",
                  "mtr_group"]


class FieldsForPatternSerializer(serializers.Serializer):
    field_name = serializers.CharField()
    mtr_group_id = serializers.IntegerField()
    field_id = serializers.IntegerField()
    supply_group_id = serializers.IntegerField()
    name = serializers.CharField()


class MtrFieldsValuesSerializer(serializers.ModelSerializer):
    class Meta:
        model = MtrFieldsValues
        fields = ['value_id', 'value', 'supply_group_field']
        depth = 2
