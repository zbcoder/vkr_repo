from django.apps import AppConfig


class KpMtrApproveConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kp_mtr_approve'
