from django.urls import path
from .views import *

urlpatterns = [
    path(r'chat/<str:unique_uid>/', ListMessages.as_view(), name='chat_messages_by_uuid'),
    path(r'chat/', CreateChatList.as_view(), name='new_chat'),
    path(r'add-message/', CreateMessage.as_view(), name='new_message_for_chat'),
]