import uuid

from django.http import Http404
from django.shortcuts import redirect
from rest_framework import status
from rest_framework.generics import RetrieveAPIView, CreateAPIView
from rest_framework.views import APIView
from rest_framework.response import Response
from django.views.generic import ListView

from .models import *
from .serializers import *


# Create your views here.

class ListMessageChat(RetrieveAPIView):
    queryset = Chatroom.objects.select_related('chatroom')
    serializer_class = ChatRoomSerializer


class CreateChatList(CreateAPIView):
    serializer_class = ChatRoomSerializer

    def create(self, request, *args, **kwargs):
        new_data = request.data
        print(new_data)
        serializer = self.get_serializer(data=new_data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


class CreateMessage(CreateAPIView):
    serializer_class = MessageSerializer


# class ListViewTemp(ListView):
#     def get(self, request, *args, **kwargs):
#         self.object_list = self.get_queryset()
#         allow_empty = self.get_allow_empty()
#
#         if not allow_empty:
#             # When pagination is enabled and object_list is a queryset,
#             # it's better to do a cheap query than to load the unpaginated
#             # queryset in memory.
#             if self.get_paginate_by(self.object_list) is not None and hasattr(self.object_list, 'exists'):
#                 is_empty = not self.object_list.exists()
#             else:
#                 is_empty = not self.object_list
#             if is_empty:
#                 raise Http404(_('Empty list and “%(class_name)s.allow_empty” is False.') % {
#                     'class_name': self.__class__.__name__,
#                 })
#         if len(self.get_context_data())==0:
#
#         context = self.get_context_data()
#         return self.render_to_response(context)


class ListMessages(APIView):
    def get(self, request, unique_uid):
        try:
            qs = Message.objects.select_related('chatroom'). \
                filter(chatroom_id__chatroom_uuid=uuid.UUID(unique_uid).hex)

            chat_qs = Chatroom.objects.filter(chatroom_uuid=uuid.UUID(unique_uid).hex)

            chat_ser = ChatRoomSerializer(chat_qs, many=True)
            serializer = MessageSerializer(qs, many=True)
            all_data = [serializer.data, chat_ser.data]
            print(len(chat_ser.data))
            if int(len(chat_ser.data)) == 0:
                return Response(status=404)
            return Response(all_data, status=200)
        except Exception as e:
            print(e)
            return Response(status=500)
