import uuid

from django.contrib.auth.decorators import permission_required
from django.db import models


# Create your models here.

class Chatroom(models.Model):
    chatroom_uuid = models.UUIDField(default=uuid.uuid4)
    chatroom_name = models.CharField(max_length=255, blank=True, null=True)
    chatroom_created_by = models.IntegerField(blank=True, null=True)
    chatroom_id = models.BigAutoField(primary_key=True)

    class Meta:
        managed = False
        db_table = 'chatroom'


class Message(models.Model):
    message_text = models.CharField(max_length=1000, blank=True, null=True)
    username = models.CharField(max_length=255, blank=True, null=True)
    post_date = models.DateTimeField(blank=True, null=True)
    message_id = models.BigAutoField(primary_key=True)
    chatroom = models.ForeignKey(Chatroom, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        ordering = ['post_date']
        managed = False
        db_table = 'message'
